insert into NAL_MSA_VLAN_MNG
(create_id, create_date, update_id, update_date, extension_info)
value
('system', now(), 'system', now(),
'{
	"pod_id":"",
	"vlan_id":"801",
	"network_address":"100.106.1.0",
	"netmask":"27",
	"msa_ip_address":"",
	"status":"0",
	"tenant_name":"","tenant_id":"","network_id":"","subnet_id":"","port_id":"","network_info":"","subnet_info":"","port_info":""
}'),
('system', now(), 'system', now(),
'{
	"pod_id":"",
	"vlan_id":"802",
	"network_address":"100.106.1.32",
	"netmask":"27",
	"msa_ip_address":"",
	"status":"0",
	"tenant_name":"","tenant_id":"","network_id":"","subnet_id":"","port_id":"","network_info":"","subnet_info":"","port_info":""
}'),
('system', now(), 'system', now(),
'{
	"pod_id":"",
	"vlan_id":"803",
	"network_address":"100.106.1.64",
	"netmask":"27",
	"msa_ip_address":"",
	"status":"0",
	"tenant_name":"","tenant_id":"","network_id":"","subnet_id":"","port_id":"","network_info":"","subnet_info":"","port_info":""
}'),
('system', now(), 'system', now(),
'{
	"pod_id":"",
	"vlan_id":"804",
	"network_address":"100.106.1.96",
	"netmask":"27",
	"msa_ip_address":"",
	"status":"0",
	"tenant_name":"","tenant_id":"","network_id":"","subnet_id":"","port_id":"","network_info":"","subnet_info":"","port_info":""
}'),
('system', now(), 'system', now(),
'{
	"pod_id":"",
	"vlan_id":"805",
	"network_address":"100.106.1.128",
	"netmask":"27",
	"msa_ip_address":"",
	"status":"0",
	"tenant_name":"","tenant_id":"","network_id":"","subnet_id":"","port_id":"","network_info":"","subnet_info":"","port_info":""
}'),
('system', now(), 'system', now(),
'{
	"pod_id":"",
	"vlan_id":"806",
	"network_address":"100.106.1.160",
	"netmask":"27",
	"msa_ip_address":"",
	"status":"0",
	"tenant_name":"","tenant_id":"","network_id":"","subnet_id":"","port_id":"","network_info":"","subnet_info":"","port_info":""
}'),
('system', now(), 'system', now(),
'{
	"pod_id":"",
	"vlan_id":"807",
	"network_address":"100.106.1.192",
	"netmask":"27",
	"msa_ip_address":"",
	"status":"0",
	"tenant_name":"","tenant_id":"","network_id":"","subnet_id":"","port_id":"","network_info":"","subnet_info":"","port_info":""
}'),
('system', now(), 'system', now(),
'{
	"pod_id":"",
	"vlan_id":"808",
	"network_address":"100.106.1.224",
	"netmask":"27",
	"msa_ip_address":"",
	"status":"0",
	"tenant_name":"","tenant_id":"","network_id":"","subnet_id":"","port_id":"","network_info":"","subnet_info":"","port_info":""
}');
