insert into NAL_VXLANGW_POD_MNG
(create_id, create_date, update_id, update_date, delete_flg, vxlangw_pod_id, extension_info)
values
('system', now(), 'system', now(), 0, '4e10ac12-d136-473d-b530-df1bd63f137c',
'{
	"IaaS_region_id":"RegionDC1",
	"weight":100
}');
