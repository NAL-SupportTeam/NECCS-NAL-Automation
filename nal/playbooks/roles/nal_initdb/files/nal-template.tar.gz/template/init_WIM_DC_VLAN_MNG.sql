insert into WIM_DC_VLAN_MNG
(create_id, create_date, update_id, update_date, extension_info)
values
('system', now(), 'system', now(),
'{
	"dc_id":"",
	"pod_id":"",
	"vlan_id":955,
	"status":0,
	"group_id":""
}' ),
('system', now(), 'system', now(),
'{
	"dc_id":"",
	"pod_id":"",
	"vlan_id":956,
	"status":0,
	"group_id":""
}' ),
('system', now(), 'system', now(),
'{
	"dc_id":"",
	"pod_id":"",
	"vlan_id":957,
	"status":0,
	"group_id":""
}' ),
('system', now(), 'system', now(),
'{
	"dc_id":"",
	"pod_id":"",
	"vlan_id":958,
	"status":0,
	"group_id":""
}' ),
('system', now(), 'system', now(),
'{
	"dc_id":"",
	"pod_id":"",
	"vlan_id":959,
	"status":0,
	"group_id":""
}' ),
('system', now(), 'system', now(),
'{
	"dc_id":"",
	"pod_id":"",
	"vlan_id":960,
	"status":0,
	"group_id":""
}' ),
('system', now(), 'system', now(),
'{
	"dc_id":"",
	"pod_id":"",
	"vlan_id":961,
	"status":0,
	"group_id":""
}' ),
('system', now(), 'system', now(),
'{
	"dc_id":"",
	"pod_id":"",
	"vlan_id":962,
	"status":0,
	"group_id":""
}' ),
('system', now(), 'system', now(),
'{
	"dc_id":"",
	"pod_id":"",
	"vlan_id":963,
	"status":0,
	"group_id":""
}' ),
('system', now(), 'system', now(),
'{
	"dc_id":"",
	"pod_id":"",
	"vlan_id":964,
	"status":0,
	"group_id":""
}' ),
('system', now(), 'system', now(),
'{
	"dc_id":"",
	"pod_id":"",
	"vlan_id":965,
	"status":0,
	"group_id":""
}' ),
('system', now(), 'system', now(),
'{
	"dc_id":"",
	"pod_id":"",
	"vlan_id":966,
	"status":0,
	"group_id":""
}' ),
('system', now(), 'system', now(),
'{
	"dc_id":"",
	"pod_id":"",
	"vlan_id":967,
	"status":0,
	"group_id":""
}' ),
('system', now(), 'system', now(),
'{
	"dc_id":"",
	"pod_id":"",
	"vlan_id":968,
	"status":0,
	"group_id":""
}' ),
('system', now(), 'system', now(),
'{
	"dc_id":"",
	"pod_id":"",
	"vlan_id":969,
	"status":0,
	"group_id":""
}' ),
('system', now(), 'system', now(),
'{
	"dc_id":"",
	"pod_id":"",
	"vlan_id":970,
	"status":0,
	"group_id":""
}' );
