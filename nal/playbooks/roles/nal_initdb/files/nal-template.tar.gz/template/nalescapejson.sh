#!/bin/sh
perl nalescapejson.pl init_NAL_APL_MNG.sql
perl nalescapejson.pl init_NAL_CONFIG_MNG.sql
perl nalescapejson.pl init_NAL_DEVICE_ENDPOINT_MNG.sql
perl nalescapejson.pl init_NAL_GLOBAL_IP_MNG.sql
perl nalescapejson.pl init_NAL_LICENSE_MNG.sql
perl nalescapejson.pl init_NAL_MSA_VLAN_MNG.sql
perl nalescapejson.pl init_NAL_POD_MNG.sql
perl nalescapejson.pl init_NAL_THRESHOLD_MNG.sql
perl nalescapejson.pl init_NAL_VXLANGW_POD_MNG.sql
perl nalescapejson.pl init_WIM_CONFIG_MNG.sql
perl nalescapejson.pl init_WIM_DC_MNG.sql
perl nalescapejson.pl init_WIM_DC_SEGMENT_MNG.sql
perl nalescapejson.pl init_WIM_DC_VLAN_MNG.sql
perl nalescapejson.pl init_WIM_DEVICE_ENDPOINT_MNG.sql
