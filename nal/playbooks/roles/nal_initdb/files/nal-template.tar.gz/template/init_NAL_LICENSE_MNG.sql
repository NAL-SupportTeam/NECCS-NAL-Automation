insert into NAL_LICENSE_MNG
(create_id, create_date, update_id, update_date, delete_flg, license, extension_info)
values
('system', now(), 'system', now(), 0, 'SGLIC-D471-GNBB-KW8N-WAM2-CPWB-VCAR-V7QH-Q71X',
'{
	"type":1,
	"device_type":1,
	"type_detail":"",
	"status":0,
	"tenant_name":"",
	"node_id":"",
	"description":""
}'),
('system', now(), 'system', now(), 0, 'SGLIC-D471-GNBB-KW8N-WAM2-CPWB-VCAR-V7QH-Q71X',
'{
	"type":1,
	"device_type":1,
	"type_detail":"",
	"status":0,
	"tenant_name":"",
	"node_id":"",
	"description":""
}'),
('system', now(), 'system', now(), 0, 'SGLIC-D471-GNBB-KW8N-WAM2-CPWB-VCAR-V7QH-Q71X',
'{
	"type":1,
	"device_type":1,
	"type_detail":"",
	"status":0,
	"tenant_name":"",
	"node_id":"",
	"description":""
}'),
('system', now(), 'system', now(), 0, 'SGLIC-D471-GNBB-KW8N-WAM2-CPWB-VCAR-V7QH-Q71X',
'{
	"type":1,
	"device_type":1,
	"type_detail":"",
	"status":0,
	"tenant_name":"",
	"node_id":"",
	"description":""
}'),
('system', now(), 'system', now(), 0, 'SGLIC-D471-GNBB-KW8N-WAM2-CPWB-VCAR-V7QH-Q71X',
'{
	"type":1,
	"device_type":4,
	"type_detail":"",
	"status":0,
	"tenant_name":"",
	"node_id":"",
	"description":""
}'),
('system', now(), 'system', now(), 0, 'SGLIC-D471-GNBB-KW8N-WAM2-CPWB-VCAR-V7QH-Q71X',
'{
	"type":1,
	"device_type":4,
	"type_detail":"",
	"status":0,
	"tenant_name":"",
	"node_id":"",
	"description":""
}'),
('system', now(), 'system', now(), 0, 'SGLIC-D471-GNBB-KW8N-WAM2-CPWB-VCAR-V7QH-Q71X',
'{
	"type":1,
	"device_type":4,
	"type_detail":"",
	"status":0,
	"tenant_name":"",
	"node_id":"",
	"description":""
}'),
('system', now(), 'system', now(), 0, 'SGLIC-D471-GNBB-KW8N-WAM2-CPWB-VCAR-V7QH-Q71X',
'{
	"type":1,
	"device_type":4,
	"type_detail":"",
	"status":0,
	"tenant_name":"",
	"node_id":"",
	"description":""
}'),
('system', now(), 'system', now(), 0, 'SGLIC-D471-GNBB-KW8N-WAM2-CPWB-VCAR-V7QH-Q71X',
'{
	"type":1,
	"device_type":4,
	"type_detail":"",
	"status":0,
	"tenant_name":"",
	"node_id":"",
	"description":""
}'),
('system', now(), 'system', now(), 0, 'bKqE-PYqG-8k0-uSoy-RdD7-nSM',
'{
	"type":2,
	"device_type":1,
	"type_detail":"",
	"status":0,
	"tenant_name":"",
	"node_id":"",
	"description":""
}'),
('system', now(), 'system', now(), 0, 'bKqE-PYqG-8k0-uSoy-RdD7-nSM',
'{
	"type":2,
	"device_type":1,
	"type_detail":"",
	"status":0,
	"tenant_name":"",
	"node_id":"",
	"description":""
}'),
('system', now(), 'system', now(), 0, 'bKqE-PYqG-8k0-uSoy-RdD7-nSM',
'{
	"type":2,
	"device_type":1,
	"type_detail":"",
	"status":0,
	"tenant_name":"",
	"node_id":"",
	"description":""
}'),
('system', now(), 'system', now(), 0, 'bKqE-PYqG-8k0-uSoy-RdD7-nSM',
'{
	"type":2,
	"device_type":1,
	"type_detail":"",
	"status":0,
	"tenant_name":"",
	"node_id":"",
	"description":""
}'),
('system', now(), 'system', now(), 0, 'bKqE-PYqG-8k0-uSoy-RdD7-nSM',
'{
	"type":2,
	"device_type":1,
	"type_detail":"",
	"status":0,
	"tenant_name":"",
	"node_id":"",
	"description":""
}');