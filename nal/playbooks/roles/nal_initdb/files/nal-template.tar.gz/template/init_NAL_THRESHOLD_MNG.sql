insert into NAL_THRESHOLD_MNG
(create_id, create_date, update_id, update_date, extension_info)
values
('system', now(), 'system', now(),
'{
	"nw_resource_kind":1,
	"type":"",
	"device_type":"",
	"redundant_configuration_flg":"",
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":1,
	"device_type":1,
	"redundant_configuration_flg":"",
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":1,
	"device_type":2,
	"redundant_configuration_flg":"",
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":1,
	"device_type":3,
	"redundant_configuration_flg":"",
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":1,
	"device_type":4,
	"redundant_configuration_flg":"",
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":2,
	"device_type":1,
	"redundant_configuration_flg":"",
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":2,
	"device_type":2,
	"redundant_configuration_flg":"",
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":2,
	"device_type":3,
	"redundant_configuration_flg":"",
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":3,
	"device_type":1,
	"redundant_configuration_flg":"",
	"type_detail":1,
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":3,
	"device_type":1,
	"redundant_configuration_flg":"",
	"type_detail":2,
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":3,
	"device_type":1,
	"redundant_configuration_flg":"",
	"type_detail":3,
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":3,
	"device_type":1,
	"redundant_configuration_flg":"",
	"type_detail":4,
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":3,
	"device_type":1,
	"redundant_configuration_flg":"",
	"type_detail":5,
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":3,
	"device_type":1,
	"redundant_configuration_flg":"",
	"type_detail":6,
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":3,
	"device_type":1,
	"redundant_configuration_flg":"",
	"type_detail":7,
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":3,
	"device_type":2,
	"redundant_configuration_flg":"",
	"type_detail":1,
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":3,
	"device_type":2,
	"redundant_configuration_flg":"",
	"type_detail":2,
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":3,
	"device_type":2,
	"redundant_configuration_flg":"",
	"type_detail":3,
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":3,
	"device_type":2,
	"redundant_configuration_flg":"",
	"type_detail":4,
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":3,
	"device_type":2,
	"redundant_configuration_flg":"",
	"type_detail":5,
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":3,
	"device_type":2,
	"redundant_configuration_flg":"",
	"type_detail":6,
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":3,
	"device_type":2,
	"redundant_configuration_flg":"",
	"type_detail":7,
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":3,
	"device_type":2,
	"redundant_configuration_flg":"",
	"type_detail":8,
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":3,
	"device_type":2,
	"redundant_configuration_flg":"",
	"type_detail":9,
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":2,
	"type":3,
	"device_type":2,
	"redundant_configuration_flg":"",
	"type_detail":10,
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":3,
	"type":1,
	"device_type":1,
	"redundant_configuration_flg":0,
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":3,
	"type":1,
	"device_type":1,
	"redundant_configuration_flg":1,
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":3,
	"type":1,
	"device_type":2,
	"redundant_configuration_flg":0,
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":3,
	"type":1,
	"device_type":2,
	"redundant_configuration_flg":1,
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":3,
	"type":1,
	"device_type":3,
	"redundant_configuration_flg":"",
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":3,
	"type":1,
	"device_type":4,
	"redundant_configuration_flg":"",
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":3,
	"type":2,
	"device_type":1,
	"redundant_configuration_flg":0,
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":3,
	"type":2,
	"device_type":1,
	"redundant_configuration_flg":1,
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":3,
	"type":2,
	"device_type":2,
	"redundant_configuration_flg":0,
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":3,
	"type":2,
	"device_type":2,
	"redundant_configuration_flg":1,
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":3,
	"type":2,
	"device_type":3,
	"redundant_configuration_flg":"",
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":3,
	"type":2,
	"device_type":4,
	"redundant_configuration_flg":"",
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":4,
	"type":"",
	"device_type":"",
	"redundant_configuration_flg":"",
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":5,
	"type":"",
	"device_type":"",
	"redundant_configuration_flg":"",
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":6,
	"type":"",
	"device_type":"",
	"redundant_configuration_flg":"",
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":7,
	"type":"",
	"device_type":"",
	"redundant_configuration_flg":"",
	"type_detail":"",
	"threshold":85
}'),
('system', now(), 'system', now(),
'{
	"nw_resource_kind":8,
	"type":"",
	"device_type":"",
	"redundant_configuration_flg":"",
	"type_detail":"",
	"threshold":85
}');
