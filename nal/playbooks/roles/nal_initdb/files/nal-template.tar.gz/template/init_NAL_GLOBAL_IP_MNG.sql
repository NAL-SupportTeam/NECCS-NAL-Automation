insert into NAL_GLOBAL_IP_MNG
(create_id, create_date, update_id, update_date, delete_flg, global_ip, extension_info)
values
('system', now(), 'system', now(), 0, '172.17.1.50', '{"status": 0, "node_id": "", "tenant_name": ""}'),
('system', now(), 'system', now(), 0, '172.17.1.51', '{"status": 0, "node_id": "", "tenant_name": ""}'),
('system', now(), 'system', now(), 0, '172.17.1.52', '{"status": 0, "node_id": "", "tenant_name": ""}'),
('system', now(), 'system', now(), 0, '172.17.1.53', '{"status": 0, "node_id": "", "tenant_name": ""}'),
('system', now(), 'system', now(), 0, '172.17.1.54', '{"status": 0, "node_id": "", "tenant_name": ""}');