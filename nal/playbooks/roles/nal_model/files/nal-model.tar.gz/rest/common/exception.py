# -*- coding: utf-8 -*-

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#


class ApiAppException(Exception):
    message = "An unknown exception occurred"

    def __init__(self, message=None):
        if not message:
            message = self.message


class NotFound(ApiAppException):
    message = "An object with the specified identifier was not found."
    code = "404 NotFound"


class Invalid(ApiAppException):
    message = "Data supplied was not valid."
    code = "400 Bad Request"


class InvalidRequestParam(Invalid):
    message = "Request param supplied was not valid."
