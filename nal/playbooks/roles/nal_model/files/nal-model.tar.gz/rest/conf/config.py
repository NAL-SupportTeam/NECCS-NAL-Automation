# -*- coding: utf-8 -*-

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#

# Database Connecting Infomation
MYSQL_HOSTNAME = 'localhost'
MYSQL_USERID = 'root'
MYSQL_PASSWORD = 'i-portal'
MYSQL_DBNAME = 'nal'

# Column DataType Conversion Definition(for SELECT)
SELECT_COLUMN_TYPE_DEF = {
    'DECIMAL':
        'CAST(%field_name% AS CHAR) AS %field_name%',
    'DATETIME':
        "DATE_FORMAT(%field_name%, '%Y-%m-%d %T') AS %field_name%",
}

# HTTP Status Definition
HTTP_STATUS_DEF = {
    'GET': '200 OK',
    'PUT': '200 OK',
    'POST': '200 OK',
    'DELETE': '200 OK',
    'ERROR': '500 Internal Server Error',
}

# Log Output Pass Definition
LOG_OUTPUT_PASS = '/var/log/nal/nal_model_trace.log'
LOG_OUTPUT_LEVEL = 'DEBUG'
