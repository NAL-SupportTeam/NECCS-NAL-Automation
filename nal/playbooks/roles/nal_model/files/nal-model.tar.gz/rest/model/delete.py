# -*- coding: utf-8 -*-

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#

from rest.common import exception
from rest.conf import tables as tables_conf
from rest.lib import database


class Delete:

    def execute(self, request_params, table_name):

        # ------------------------------------------------------
        # Initialaize
        # ------------------------------------------------------
        table_conf = getattr(tables_conf, table_name, {})
        table_pkey = table_conf.get('primaryKey')
        request_params_id = request_params.get('id')

        # Create Instance(LibDatabase)
        db = database.LibDatabase()

        # ------------------------------------------------------
        # Get Current Record(extension_info)
        # ------------------------------------------------------
        sel_sql = ''
        sel_param_vals = []
        sel_sql_where = ''

        sel_sql = 'SELECT * '
        sel_sql += ' FROM ' + table_name

        if len(table_pkey) > 0 and len(request_params_id) == len(table_pkey):
            sel_sql_where = ' WHERE '
            sel_sql_where += ' = %s AND '.join(table_pkey) + ' = %s '
            sel_param_vals = request_params_id
        else:
            raise exception.InvalidRequestParam

        sel_sql += sel_sql_where

        res = db.execute_sql(sel_sql, sel_param_vals)
        if len(res) == 0:
            raise exception.NotFound

        # ------------------------------------------------------
        # Delete Record
        # ------------------------------------------------------
        sql = 'DELETE FROM ' + table_name
        sql_where = ''
        param_vals = []

        sql_where = ' WHERE '
        sql_where += ' = %s AND '.join(table_pkey) + ' = %s '
        param_vals += request_params_id

        sql += sql_where

        # Execute SQL
        return db.execute_sql(sql, param_vals)
