COMMAND = 'nal'
COMMAND_ARGS_OS_CLIENT_URL_NAME = '--os-nal-url'
ENV_OS_CLIENT_URL_NAME = 'OS_NAL_URL'

# This value is appname(/nalclient folder name)
# of OpenStack Common constraint.
SHELL_LOGGER_NAME = 'nalclient'
