<?php
#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#
/**
 * 1.SYSTEM   : API Controller
* 2.FUNCTION : all_resource.php (Individual method)
*/
require_once dirname(__FILE__). '/../Nal.php';

class all_resource extends neccsNal {

    /**
     * GET method (list,refer)
     *
     */
    protected function get() {

        // If you are an administrator
        if( !isset( $this->_p['IaaS_tenant_id'] )  ){

            if( $this->_nalConf['api_type'] === neccsNal_Config::API_TYPE_NAL ){

                // Get the ten information
                $url  = neccsNal_Config::API_URL;
                $url .= neccsNal_Config::API_URL_LIST;
                $url .= neccsNal_Config::RESOURCE_THRESHOLDS;
                $request_id = isset( $this->_p['request-id'] ) ? $this->_p['request-id'] : $this->_requestId;
                $url .= '?' . 'request-id=' . $request_id;
                $url .= '&' . 'delete_flg=0';

                $url_list['threshold_info'] = $url;

                // Get the tenant contract information
                $url  = neccsNal_Config::API_URL;
                $url .= neccsNal_Config::API_URL_LIST;
                $url .= neccsNal_Config::RESOURCE_CONTRACT;
                $request_id = isset( $this->_p['request-id'] ) ? $this->_p['request-id'] : $this->_requestId;
                $url .= '?' . 'request-id=' . $request_id;
                $url .= '&' . 'delete_flg=0';

                $url_list['tenant_contract_info'] = $url;

                // Get the tenant contract information
                $url  = neccsNal_Config::API_URL;
                $url .= neccsNal_Config::API_URL_LIST;
                $url .= neccsNal_Config::RESOURCE_PODS;
                $request_id = isset( $this->_p['request-id'] ) ? $this->_p['request-id'] : $this->_requestId;
                $url .= '?' . 'request-id=' . $request_id;
                $url .= '&' . 'delete_flg=0';

                $url_list['pod_info'] = $url;

                // Get the msa information
                $url  = neccsNal_Config::API_URL;
                $url .= neccsNal_Config::API_URL_LIST;
                $url .= neccsNal_Config::RESOURCE_MSA;
                $request_id = isset( $this->_p['request-id'] ) ? $this->_p['request-id'] : $this->_requestId;
                $url .= '?' . 'request-id=' . $request_id;
                $url .= '&' . 'delete_flg=0';

                $url_list['msa_info'] = $url;

                // Get the license information
                $url  = neccsNal_Config::API_URL;
                $url .= neccsNal_Config::API_URL_LIST;
                $url .= neccsNal_Config::RESOURCE_LICENSES;
                $request_id = isset( $this->_p['request-id'] ) ? $this->_p['request-id'] : $this->_requestId;
                $url .= '?' . 'request-id=' . $request_id;
                $url .= '&' . 'delete_flg=0';

                $url_list['license_info'] = $url;

                // Get the apl information
                $url  = neccsNal_Config::API_URL;
                $url .= neccsNal_Config::API_URL_LIST;
                $url .= neccsNal_Config::RESOURCE_APLS;
                $request_id = isset( $this->_p['request-id'] ) ? $this->_p['request-id'] : $this->_requestId;
                $url .= '?' . 'request-id=' . $request_id;
                $url .= '&' . 'delete_flg=0';

                $url_list['apl_info'] = $url;

                // Get the apl information
                $url  = neccsNal_Config::API_URL;
                $url .= neccsNal_Config::API_URL_LIST;
                $url .= neccsNal_Config::RESOURCE_GLOBAL_IP_ADDR;
                $request_id = isset( $this->_p['request-id'] ) ? $this->_p['request-id'] : $this->_requestId;
                $url .= '?' . 'request-id=' . $request_id;
                $url .= '&' . 'delete_flg=0';

                $url_list['global_ip_address_info'] = $url;

                $execList = $this->_execMultiApi( $url_list );

                // Get the flavor contract information
                $execList['flavor_contract_info'] = $this->_getContractCnt();

                // Get the qupta and use_cnt information
                $execList['quota_and_use_info'] = $this->_getQuotaAndUseCnt( $execList );

                // Create a URL (Call of WIM API)
                $url = neccsNal_Config::WIM_API_URL . str_replace( '/Nal/', '', $_SERVER['REQUEST_URI'] );
                $url .= '&request-id='. $this->_p['request-id'];

                // API execution
                $resultForWim = array();
                $resultForWim = $this->_execApi( $url );

                $status = isset( $resultForWim['result']['status'] ) ? $resultForWim['result']['status'] : '';
                if( $status === neccsNal_Config::STATUS_SUCCESS ) {
                    $data = $resultForWim['data'];
                } else {
                    $this->_execResult( $resultForWim, $url );
                }

                // get the use_cnt
                $result = $this->_getContInfo( array_merge( $execList, $data ) );

                foreach( $result['contract_info'] as $key => $value ){
                    unset( $result['contract_info'][$key]['function_type'] );
                }

                $url = neccsNal_Config::NAL_API_URL . str_replace( '/Nal/', '', $_SERVER['REQUEST_URI'] );
                $this->logit( neccsNal_Config::SUCCESS_CODE, "OutPut Data ( $url )", $this->_p, $result );

                $this->success( $result );
            }
        } else if ( isset( $this->_p['IaaS_tenant_id'] ) ) {

            $tenant_name = $this->_getTenant( $this->_p['IaaS_tenant_id'] );

            if( $this->_nalConf['api_type'] === neccsNal_Config::API_TYPE_NAL ){

                // Get the tenant contract information
                $url  = neccsNal_Config::API_URL;
                $url .= neccsNal_Config::API_URL_LIST;
                $url .= neccsNal_Config::RESOURCE_CONTRACT;
                $request_id = isset( $this->_p['request-id'] ) ? $this->_p['request-id'] : $this->_requestId;
                $url .= '?' . 'request-id=' . $request_id;
                $url .= '&' . 'tenant_name=' . $tenant_name;
                $url .= '&' . 'delete_flg=0';

                $url_list['tenant_contract_info'] = $url;

                // Get the license information
                $url  = neccsNal_Config::API_URL;
                $url .= neccsNal_Config::API_URL_LIST;
                $url .= neccsNal_Config::RESOURCE_LICENSES;
                $request_id = isset( $this->_p['request-id'] ) ? $this->_p['request-id'] : $this->_requestId;
                $url .= '?' . 'request-id=' . $request_id;
                $url .= '&' . 'tenant_name=' . $tenant_name;
                $url .= '&' . 'delete_flg=0';

                $url_list['license_info'] = $url;

                // Get the apl information
                $url  = neccsNal_Config::API_URL;
                $url .= neccsNal_Config::API_URL_LIST;
                $url .= neccsNal_Config::RESOURCE_APLS;
                $request_id = isset( $this->_p['request-id'] ) ? $this->_p['request-id'] : $this->_requestId;
                $url .= '?' . 'request-id=' . $request_id;
                $url .= '&' . 'tenant_name=' . $tenant_name;
                $url .= '&' . 'delete_flg=0';

                $url_list['apl_info'] = $url;

                // Get the apl information
                $url  = neccsNal_Config::API_URL;
                $url .= neccsNal_Config::API_URL_LIST;
                $url .= neccsNal_Config::RESOURCE_GLOBAL_IP_ADDR;
                $request_id = isset( $this->_p['request-id'] ) ? $this->_p['request-id'] : $this->_requestId;
                $url .= '?' . 'request-id=' . $request_id;
                $url .= '&' . 'tenant_name=' . $tenant_name;
                $url .= '&' . 'delete_flg=0';

                $url_list['global_ip_address_info'] = $url;

                $execList = $this->_execMultiApi( $url_list );

                // Create a URL (Call of WIM API)
                $url = neccsNal_Config::WIM_API_URL . str_replace( '/Nal/', '', $_SERVER['REQUEST_URI'] );
                $url .= '&request-id='. $this->_p['request-id'];

                // API execution
                $resultForWim = array();
                $resultForWim = $this->_execApi( $url );

                $status = isset( $resultForWim['result']['status'] ) ? $resultForWim['result']['status'] : '';
                if( $status === neccsNal_Config::STATUS_SUCCESS ) {
                    $data = $resultForWim['data'];
                } else {
                    $this->_execResult( $resultForWim, $url );
                }

                // get the use_cnt
                $result = $this->_getContInfoTenant( array_merge( $execList, $data ) );

                foreach( $result['contract_info'] as $key => $value ){
                    unset( $result['contract_info'][$key]['function_type'] );
                }

                $url = neccsNal_Config::NAL_API_URL . str_replace( '/Nal/', '', $_SERVER['REQUEST_URI'] );
                $this->logit( neccsNal_Config::SUCCESS_CODE, "OutPut Data ( $url )", $this->_p, $result );

                $this->success( $result );

            }

        }

        if( $this->_nalConf['api_type'] === neccsNal_Config::API_TYPE_WIM ){

            if( !isset( $this->_p['IaaS_tenant_id'] )  ){

                if( !isset( $this->_['pod_id'] ) ){

                    // Get the dc dc group information
                    $url  = neccsNal_Config::API_URL;
                    $url .= neccsNal_Config::API_URL_LIST;
                    $url .= neccsNal_Config::RESOURCE_DC_CON_GROUPS;
                    $request_id = isset( $this->_p['request-id'] ) ? $this->_p['request-id'] : $this->_requestId;
                    $url .= '?' . 'request-id=' . $request_id;
                    $url .= '&' . 'delete_flg=0';

                    $url_list['dc_group_info'] = $url;

                    // Get the dc member information
                    $url  = neccsNal_Config::API_URL;
                    $url .= neccsNal_Config::API_URL_LIST;
                    $url .= neccsNal_Config::RESOURCE_DC_CON_MEMBERS;
                    $request_id = isset( $this->_p['request-id'] ) ? $this->_p['request-id'] : $this->_requestId;
                    $url .= '?' . 'request-id=' . $request_id;
                    $url .= '&' . 'delete_flg=0';

                    $url_list['dc_member_info'] = $url;

                    // Get the Wan information
                    $url  = neccsNal_Config::API_URL;
                    $url .= neccsNal_Config::API_URL_LIST;
                    $url .= neccsNal_Config::RESOURCE_WAN;
                    $request_id = isset( $this->_p['request-id'] ) ? $this->_p['request-id'] : $this->_requestId;
                    $url .= '?' . 'request-id=' . $request_id;

                    $url_list['wan_info'] = $url;

                    $execList = $this->_execMultiApi( $url_list );

                } else {
                    $result = $this->_execProcess( $this->_p['pod_id'] );
                }

            } else if ( isset( $this->_p['IaaS_tenant_id'] ) ) {

                $tenant_name = $this->_getTenant( $this->_p['IaaS_tenant_id'] );

                // Get the dc dc group information
                $url  = neccsNal_Config::API_URL;
                $url .= neccsNal_Config::API_URL_LIST;
                $url .= neccsNal_Config::RESOURCE_DC_CON_GROUPS;
                $request_id = isset( $this->_p['request-id'] ) ? $this->_p['request-id'] : $this->_requestId;
                $url .= '?' . 'request-id=' . $request_id;
                $url .= '&' . 'tenant_name=' . $tenant_name;
                $url .= '&' . 'delete_flg=0';

                $url_list['dc_group_info'] = $url;

                // Get the dc member information
                $url  = neccsNal_Config::API_URL;
                $url .= neccsNal_Config::API_URL_LIST;
                $url .= neccsNal_Config::RESOURCE_DC_CON_MEMBERS;
                $request_id = isset( $this->_p['request-id'] ) ? $this->_p['request-id'] : $this->_requestId;
                $url .= '?' . 'request-id=' . $request_id;
                $url .= '&' . 'tenant_name=' . $tenant_name;
                $url .= '&' . 'delete_flg=0';

                $url_list['dc_member_info'] = $url;

                $execList = $this->_execMultiApi( $url_list );

            }

            $this->success( $execList );
        }
    }

    /**
     * Format information acquired from REST API ( tenant user )
     *
     * @param REST API information
     *
     * @return $result
     */
    protected function _getContInfoTenant( $execList ){

        $result['contract_info'] = array();
        $ID = 0;

        ///// Appliance /////
        foreach( neccsNal_Config::$allResourceParam[neccsNal_Config::LICENSE] as $licenseParam ){

            $param = array();
            $param = $licenseParam;

            $data = array();
            $data = $param;
            list( $data['contract_cnt'], )    = $this->_getContractCntLicense( $execList, $param );
            list( $data['use_cnt'], )         = $this->_getUseCntLicense( $execList, $param );
            if( $data['contract_cnt'] > 0 || $data['use_cnt'] > 0 ){

                if( $data['type'] == 3 ){
                    $data['contract_kind'] = '3';
                } else {
                    $data['contract_kind'] = '2';
                }

                unset( $data['type_detail'] );
                unset( $data['nw_resource_kind'] );
                $result['contract_info'][] = $data;
            }
        }

        ///// PNF /////
        foreach( neccsNal_Config::$allResourceParam[neccsNal_Config::PNF] as $pnfParam ){

            if( is_array( $pnfParam['redundant_configuration_flg'] ) ){
                foreach( $pnfParam['redundant_configuration_flg'] as $redundant_configuration_flg ){

                    $param = array();
                    $param = $pnfParam;
                    $param['redundant_configuration_flg'] = $redundant_configuration_flg;

                    $data = array();
                    $data = $param;
                    $data['contract_kind']   = '2';
                    $data['contract_cnt']    = $this->_getContractCntPnf( $execList, $param );
                    $data['use_cnt']         = $this->_getUseCntPnf( $execList, $param );
                    if( $data['contract_cnt'] > 0 || $data['use_cnt'] > 0 ){
                        unset( $data['type_detail'] );
                        unset( $data['nw_resource_kind'] );
                        $result['contract_info'][] = $data;
                    }
                }
            } else {
                $param = array();
                $param = $pnfParam;

                $data = array();
                $data = $param;
                $data['contract_kind']   = '2';
                $data['contract_cnt']    = $this->_getContractCntPnf( $execList, $param );
                $data['use_cnt']         = $this->_getUseCntPnf( $execList, $param );
                if( $data['contract_cnt'] > 0 || $data['use_cnt'] > 0 ){
                    unset( $data['type_detail'] );
                    unset( $data['nw_resource_kind'] );
                    $result['contract_info'][] = $data;
                }
            }
        }
        ///// EXT Globalip /////
        $param = array();
        $param = neccsNal_Config::$allResourceParam[neccsNal_Config::EXT_GLOBALIP];

        $data = array();
        $data = $param;
        $data['contract_kind']   = '1';
        $data['contract_cnt']    = $this->_getContractCntGlobalip( $execList, $param );
        $data['use_cnt']         = $this->_getUseCntGlobalip( $execList, $param );
        if( $data['contract_cnt'] > 0 || $data['use_cnt'] > 0 ){
            unset( $data['type_detail'] );
            unset( $data['nw_resource_kind'] );
            $result['contract_info'][] = $data;
        }

        return $result;
    }

    /**
     * Format information acquired from REST API
     *
     * @param REST API information
     *
     * @return $result
     */
    protected function _getContInfo( $execList ){

        $result['contract_info'] = array();

        ///// License /////
        foreach( neccsNal_Config::$allResourceParam[neccsNal_Config::LICENSE] as $licenseParam ){

            if( is_array( $licenseParam['type_detail'] ) ){
                foreach( $licenseParam['type_detail'] as $type_detail ){

                    $param = array();
                    $param = $licenseParam;;
                    $param['type_detail'] = $type_detail;

                    $data = array();
                    $data = $param;
                    $data['quota']                    = $this->_getQuotaLisence( $execList, $param );
                    $data['threshold']                = $this->_getThreshold( $execList, $param );
                    list( $data['contract_cnt'], )    = $this->_getContractCntLicense( $execList, $param );
                    list( $data['use_cnt'], )         = $this->_getUseCntLicense( $execList, $param );
                    $data['unavailable_cnt']          = $this->_getUnavailableCntLicense( $execList, $param );
                    $warning_flg = $this->setWarningFlg( $data['quota'], $data['use_cnt'], $data['unavailable_cnt'], $data['threshold'] );
                    if( $warning_flg === 1 ){
                        $data['warning_flg'] = $warning_flg;
                    }
                    if( $data['quota'] > 0  ){
                        $result['contract_info'][] = $data;
                    }
                }
            } else {
                $param = array();
                $param = $licenseParam;

                $data = array();
                $data = $param;
                $data['quota']                    = $this->_getQuotaLisence( $execList, $param );
                $data['threshold']                = $this->_getThreshold( $execList, $param );
                list( $data['contract_cnt'], )    = $this->_getContractCntLicense( $execList, $param );
                list( $data['use_cnt'], )         = $this->_getUseCntLicense( $execList, $param );
                $data['unavailable_cnt'] = $this->_getUnavailableCntLicense( $execList, $param );
                $warning_flg = $this->setWarningFlg( $data['quota'], $data['use_cnt'], $data['unavailable_cnt'], $data['threshold'] );
                if( $warning_flg === 1 ){
                    $data['warning_flg'] = $warning_flg;
                }
                if( $data['quota'] > 0 ){
                    $result['contract_info'][] = $data;
                }

            }
        }

        ///// PNF /////
        foreach( neccsNal_Config::$allResourceParam[neccsNal_Config::PNF] as $pnfParam ){

            if( is_array( $pnfParam['redundant_configuration_flg'] ) ){
                foreach( $pnfParam['redundant_configuration_flg'] as $redundant_configuration_flg ){

                    $param = array();
                    $param = $pnfParam;
                    $param['redundant_configuration_flg'] = $redundant_configuration_flg;

                    $data = array();
                    $data = $param;
                    $data['quota']           = $this->_getQuotaPnf( $execList, $param );
                    $data['threshold']       = $this->_getThreshold( $execList, $param );
                    $data['contract_cnt']    = $this->_getContractCntPnf( $execList, $param );
                    $data['use_cnt']         = $this->_getUseCntPnf( $execList, $param );
                    $data['unavailable_cnt'] = $this->_getUnavailableCntPnf( $execList, $param );
                    $warning_flg = $this->setWarningFlg( $data['quota'], $data['use_cnt'], $data['unavailable_cnt'], $data['threshold'] );
                    if( $warning_flg === 1 ){
                        $data['warning_flg'] = $warning_flg;
                    }
                    if( $data['quota'] > 0 ){
                        $result['contract_info'][] = $data;
                    }
                }
            } else {
                $param = array();
                $param = $pnfParam;

                $data = array();
                $data = $param;
                $data['quota']           = $this->_getQuotaPnf( $execList, $param );
                $data['threshold']       = $this->_getThreshold( $execList, $param );
                $data['contract_cnt']    = $this->_getContractCntPnf( $execList, $param );
                $data['use_cnt']         = $this->_getUseCntPnf( $execList, $param );
                $data['unavailable_cnt'] = $this->_getUnavailableCntPnf( $execList, $param );
                $warning_flg = $this->setWarningFlg( $data['quota'], $data['use_cnt'], $data['unavailable_cnt'], $data['threshold'] );
                if( $warning_flg === 1 ){
                    $data['warning_flg'] = $warning_flg;
                }
                if( $data['quota'] > 0 ){
                    $result['contract_info'][] = $data;
                }
            }
        }
        ///// Globalip /////
        $param = array();
        $param = neccsNal_Config::$allResourceParam[neccsNal_Config::GLOBALIP];

        $data = array();
        $data = $param;
        $data['quota']           = $this->_getQuotaGlobalip( $execList );
        $data['threshold']       = $this->_getThreshold( $execList, $param );
        $data['contract_cnt']    = $this->_getContractCntGlobalip( $execList, $param );
        $data['use_cnt']         = $this->_getUseCntGlobalip( $execList, $param );
        $data['unavailable_cnt'] = $this->_getUnavailableCntGlobalip( $execList );
        $warning_flg = $this->setWarningFlg( $data['quota'], $data['use_cnt'], $data['unavailable_cnt'], $data['threshold'] );
        if( $warning_flg === 1 ){
            $data['warning_flg'] = $warning_flg;
        }
        if( $data['quota'] > 0 ){
            $result['contract_info'][] = $data;
        }

        ///// MSA VLAN /////
        $param = array();
        $param = neccsNal_Config::$allResourceParam[neccsNal_Config::MSA_VLAN];

        $data = array();
        $data = $param;
        $data['quota'] = $this->_getQuotaMsa( $execList );

        $data['threshold']       = $this->_getThreshold( $execList, $param );
        $data['contract_cnt']    = $this->_getContractCntMsa( $execList );
        $data['use_cnt']         = $this->_getUseCntMsa( $execList, $param );
        $data['unavailable_cnt'] = $this->_getUnavailableCntMsa( $execList );
        $warning_flg = $this->setWarningFlg( $data['quota'], $data['use_cnt'], $data['unavailable_cnt'], $data['threshold'] );
        if( $warning_flg === 1 ){
            $data['warning_flg'] = $warning_flg;
        }
        if( $data['quota'] > 0 ){
            $result['contract_info'][] = $data;
        }

        ///// WAN VLAN /////
        $param = array();
        $param = neccsNal_Config::$allResourceParam[neccsNal_Config::WAN_VLAN];

        $data = array();
        $data = $param;
        $data['quota'] = $this->_getQuotaWan( $execList );
        $data['threshold']       = $this->_getThreshold( $execList, $param );
        $data['contract_cnt']    = $this->_getContractCntWan( $execList );
        $data['use_cnt']         = $this->_getUseCntWan( $execList, $param );
        $data['unavailable_cnt'] = $this->_getUnavailableCntWan( $execList );
        $warning_flg = $this->setWarningFlg( $data['quota'], $data['use_cnt'], $data['unavailable_cnt'], $data['threshold'] );
        if( $warning_flg === 1 ){
            $data['warning_flg'] = $warning_flg;
        }
        if( $data['quota'] > 0 ){
            $result['contract_info'][] = $data;
        }


        foreach( $execList['quota_and_use_info'] as $key => $value ){

            //// CPU ////
            $param = array();
            $param = neccsNal_Config::$allResourceParam[neccsNal_Config::CPU_LIST];

            $data = array();
            $data = $param;
            $data['type_detail']      = $key;
            $data['contract_cnt']     = $execList['flavor_contract_info']['vcpus']['count'];
            $data['use_cnt']          = $value['vcpus']['use_cnt'];
            $data['quota']            = $value['vcpus']['quota'];
            $data['threshold']        = $this->_getThreshold( $execList, $param );
            $warning_flg = $this->setWarningFlg( $data['quota'], $data['use_cnt'], '', $data['threshold'] );
            if( $warning_flg === 1 ){
                $data['warning_flg'] = $warning_flg;
            }

            if( $data['quota'] > 0 ){
                $result['contract_info'][] = $data;
            }

            //// MEMORY ////
            $param = array();
            $param = neccsNal_Config::$allResourceParam[neccsNal_Config::MEMORY_LIST];

            $data = array();
            $data = $param;
            $data['type_detail']      = $key;
            $data['contract_cnt']     = $this->_setUnitForMemory( $execList['flavor_contract_info']['ram']['count'] );
            $data['use_cnt']          = $this->_setUnitForMemory( $value['ram']['use_cnt'] );
            $data['quota']            = $this->_setUnitForMemory( $value['ram']['quota'] );
            $data['threshold']        = $this->_getThreshold( $execList, $param );
            $warning_flg = $this->setWarningFlg( $data['quota'], $data['use_cnt'], '', $data['threshold'] );
            if( $warning_flg === 1 ){
                $data['warning_flg'] = $warning_flg;
            }

            if( $data['quota'] > 0 ){
                $result['contract_info'][] = $data;
            }

            //// STORAGE ////
            $param = array();
            $param = neccsNal_Config::$allResourceParam[neccsNal_Config::STORAGE_LIST];

            $data = array();
            $data = $param;
            $data['type_detail']      = $key;
            $data['contract_cnt']     = $this->_setUnitForStorage( $execList['flavor_contract_info']['disk']['count'] );
            $data['use_cnt']          = $this->_setUnitForStorage( $value['disk']['use_cnt'] );
            $data['quota']            = $this->_setUnitForStorage( $value['disk']['quota'] );
            $data['threshold']        = $this->_getThreshold( $execList, $param );
            $warning_flg = $this->setWarningFlg( $data['quota'], $data['use_cnt'], '', $data['threshold'] );
            if( $warning_flg === 1 ){
                $data['warning_flg'] = $warning_flg;
            }

            if( $data['quota'] > 0 ){
                $result['contract_info'][] = $data;
            }
        }

        return $result;
    }

    /**
     * Return of the response
     *
     * @param Execution result
     * @param URL
     */
    protected function _execResult( $result, $url ) {

        // If the API execution result contains the "result", the result is output directly
        if ( array_key_exists( 'result', $result ) ) {

            // Get the error code
            $code = $result['result']['error-code'];
            if( in_array( $code, neccsNal_Config::$successApiCode ) ){
                // Output log
                $this->logit( neccsNal_Config::SUCCESS_CODE, "WIM API success ( $url )", $this->_p, $result );

                // If you are running the PHPUnit test, as it is the end
                if( defined( 'PHPUNIT_RUN' ) ){
                    return;
                }

                // In the case of error
            }else if( in_array( $code, neccsNal_Config::$errorApiCode ) ){
                $errMsg = $result['result']['message'];
                // Output log
                $this->logit( neccsNal_Config::REST_API_ERROR, $errMsg, '', $result );
            }

            // If you are running the PHPUnit test, as it is the end
            if( defined( 'PHPUNIT_RUN' ) ){
                throw new Exception( $result['result']['message'] );
            }

            header( "HTTP/1.1 200" );
            header( neccsNal_Config::CONTENT_TYPE_JSON );
            print json_encode( $result );
            exit(0);
        }
    }

    /**
     * Acquire the number of contracts
     *
     * @param pod_id
     *
     * @return Tenant Information
     */
    protected function _getContractCnt(){

        // get the tenant contract
        $inParam = array();
        $inParam['contract_kind'] = '2';
        $inParam['apl_type']         = '1';
        $tenantContractInfo = $this->getTenantContract( $inParam );

        // get the DB information
        $inParam = array();
        $inParam['type']       = '5';
        $inParam['no_wim_flg'] = '1';
        $inParam['dc_id']      = 'system';
        // get the config
        $confInfo = array();
        $floverList = array();
        $confInfo = $this->getConfig( $inParam );

        if( empty( $confInfo ) ){
            $contract_cnt['vcpus']['count'] = 0;
            $contract_cnt['ram']['count']   = 0;
            $contract_cnt['disk']['count']  = 0;
            return $contract_cnt;
        }

        $confInfo = json_decode( $confInfo[0]['config_info'], true );
        $floverList = $confInfo['os_image_and_flavor_name_list'];

        $inParam = array();
        $inParam['type'] = '1';
        // Acquisition of endpoint information
        $endpointInfo = $this->getEndpoint( $inParam );

        if( empty( $endpointInfo ) ){
            $contract_cnt['vcpus']['count'] = 0;
            $contract_cnt['ram']['count']   = 0;
            $contract_cnt['disk']['count']  = 0;
            return $contract_cnt;
        }

        // Reference of OpenStack information
        $endpoint     = json_decode( $endpointInfo[0]['endpoint_info'], true );
        $tenant_name  = $endpoint['admin_tenant_name'];

        $flavorCntInfo    = $this->listFlavorsDetail( $tenant_name, $endpoint );
        $floverListForCtr = $this->setFloverData( $floverList, $flavorCntInfo );

        $contract_cnt['vcpus']['count'] = 0;
        $contract_cnt['ram']['count']   = 0;
        $contract_cnt['disk']['count']  = 0;
        foreach( $floverListForCtr as $type => $info1 ){
            foreach( $info1 as $device_type => $total ){
                foreach( $tenantContractInfo as $key => $value ){
                    if( $value['type'] == $type && $value['device_type'] == $device_type ){
                        $contract_cnt['vcpus']['count'] += $total['vcpus_count'] * $value['contract'];
                        $contract_cnt['ram']['count'] += $total['ram_count'] * $value['contract'];
                        $contract_cnt['disk']['count'] += $total['disk_count'] * $value['contract'];
                    }
                }
            }
        }

        return $contract_cnt;

    }

    /**
     * Set flover data
     *
     * @param flover list
     * @param flover contract list
     *
     * @return flover list
     */
    protected function setFloverData( $floverList, $flavorCntInfo ) {

        $setFlovoerList = array();
        foreach( $floverList as $type => $info1 ){
            foreach( $info1 as $device_type => $value ){
                $name = $value['flavor_name'];

                foreach( $flavorCntInfo['flavors'] as $key => $floverCnt ){
                    if( $floverCnt['name'] === $name ){
                        // set total_info
                        $setFlovoerList[$type][$device_type]['vcpus_count'] = $floverCnt['vcpus'];
                        $setFlovoerList[$type][$device_type]['ram_count'] = $floverCnt['ram'];
                        $setFlovoerList[$type][$device_type]['disk_count'] = $floverCnt['disk'];
                    }
                }
            }
        }

        return $setFlovoerList;
    }

    /**
     * get Quota and use_cnt information
     *
     * @param REST API information
     *
     * @return Quota and use_cnt information
     */
    protected function _getQuotaAndUseCnt( $execList ) {

        $result = array();
        foreach( $execList['pod_info'] as $key => $pod ){

            $pod_id = $pod['pod_id'];
            $use_type = $pod['use_type'];

            if( $use_type === '2' ){

                // Create a URL (Call of WIM API)
                $url = neccsNal_Config::WIM_API_URL . str_replace( '/Nal/', '', $_SERVER['REQUEST_URI'] );
                $url .= '&request-id='. $this->_p['request-id'];
                $url .= '&pod_id='. $pod_id;

                // API execution
                $resultForWim = array();
                $resultForWim = $this->_execApi( $url );
                $status = isset( $resultForWim['result']['status'] ) ? $resultForWim['result']['status'] : '';
                if( $status === neccsNal_Config::STATUS_SUCCESS ) {
                    $data = $resultForWim['data'];
                } else {
                    $this->_execResult( $resultForWim, $url );
                }
            } else {
                $data = $this->_execProcess( $pod_id );
            }

            if( !empty( $data ) ){

                if( !isset( $result[$use_type] ) ){
                    $result[$use_type]['vcpus']['quota']   = 0;
                    $result[$use_type]['vcpus']['use_cnt'] = 0;
                    $result[$use_type]['disk']['quota']    = 0;
                    $result[$use_type]['disk']['use_cnt']  = 0;
                    $result[$use_type]['ram']['quota']     = 0;
                    $result[$use_type]['ram']['use_cnt']   = 0;
                }

                $result[$use_type]['vcpus']['quota']   += $data['vcpus']['quota'];
                $result[$use_type]['vcpus']['use_cnt'] += $data['vcpus']['use_cnt'];
                $result[$use_type]['disk']['quota']    += $data['disk']['quota'];
                $result[$use_type]['disk']['use_cnt']  += $data['disk']['use_cnt'];
                $result[$use_type]['ram']['quota']     += $data['ram']['quota'];
                $result[$use_type]['ram']['use_cnt']   += $data['ram']['use_cnt'];
            }
        }

        return $result;
    }

    /**
     * Acquire upper limit number and usage number
     *
     * @return Tenant Information
     */
    protected function _execProcess( $pod_id ){

        $inParam = array();
        if( $this->_nalConf['api_type'] === neccsNal_Config::API_TYPE_WIM ){
            $inParam['dc_id'] = neccsNal_Config::MY_DC_ID;
        } else if( $this->_nalConf['api_type'] === neccsNal_Config::API_TYPE_NAL ) {
            $inParam['dc_id'] = 'system';
        }

        $inParam['pod_id'] = $pod_id;
        $inParam['type'] = '1';
        // Acquisition of endpoint information
        $endpointInfo = $this->getEndpoint( $inParam );

        if( empty( $endpointInfo ) ){
            return array();
        }

        // Reference of OpenStack information
        $endpoint     = json_decode( $endpointInfo[0]['endpoint_info'], true );
        $tenant_name  = $endpoint['admin_tenant_name'];

        // Get the information from OpenStack
        // Memory, CPU, and storage
        $usagesInfo = $this->listUsageReport( $tenant_name, $endpoint );
        $quotaInfo  = $this->listHostDetail( $tenant_name, $endpoint );

        $tenantList = array();
        $tenantList = $this->_getTenantForId();

        $info = array();
        $info = $this->setData( $tenantList, $usagesInfo, $quotaInfo );

        return $info;

    }

    /**
     * Formatting data
     *
     * @param tenant information
     * @param usage information
     * @param quota information
     *
     */
    protected function setData( $tenantList, $usagesInfo, $quotaInfo ) {
        $info = array(
            'vcpus' => array(
                'quota'   => 0,
                'use_cnt' => 0,
            ),
            'disk' => array(
                'quota'   => 0,
                'use_cnt' => 0,
            ),
            'ram' => array(
                'quota'   => 0,
                'use_cnt' => 0,
            )
        );

        $usageList = array();
        ///////// In the case usage /////////
        if( !empty( $usagesInfo['tenant_usages'] ) ){
            foreach( $usagesInfo['tenant_usages'] as $serverList ){

                // Get the tenant_name
                $tenant_id = $serverList['tenant_id'];
                $tenant_name = isset( $tenantList[$tenant_id] ) ? $tenantList[$tenant_id]['tenant_name'] : '';

                if( $tenant_name === '' ){
                    continue;
                }

                foreach( $serverList['server_usages'] as $value ){
                    // set total_info and contract_info
                    $info['vcpus']['use_cnt'] += $value['vcpus'];
                    $info['ram']['use_cnt']   += $value['memory_mb'];
                    $info['disk']['use_cnt']  += $value['local_gb'];
                }
            }
        }

        ///////// In the case quota /////////
        foreach( $quotaInfo as $quotaList ){
            // set total_info
            $info['vcpus']['quota'] += $quotaList['cpu'];
            $info['ram']['quota'] += $quotaList['memory_mb'];
            $info['disk']['quota'] += $quotaList['disk_gb'];
        }

        return $info;
    }

    /**
     * If the number of uses exceeds the threshold value, the flag is returned
     *
     * @param $quota
     * @param $use_cnt
     * @param $unavailable_cnt
     * @param $threshold
     *
     * @return Warning flg
     */
    protected function setWarningFlg( $quota, $use_cnt, $unavailable_cnt=0, $threshold ){

        $warning_flg = 0;
        $percent = 0;
        if( $use_cnt == 0 && $unavailable_cnt == 0 ){
            $percent = 0;
        } else if ( $quota == 0 ) {
            $percent = 0;
        } else {
            $percent = round( ( ( $use_cnt + $unavailable_cnt ) / $quota ) * 100 );
        }

        if( $percent > $threshold ){
            $warning_flg = 1;
        }

        return $warning_flg;
    }

    /**
     * Get the tenant_name that brute string to id
     *
     * @return Tenant Information
     */
    protected function _getTenantForId(){

        $url = neccsNal_Config::API_URL . neccsNal_Config::API_URL_LIST . neccsNal_Config::RESOURCE_TENANTS;
        $request_id = isset( $this->_p['request-id'] ) ? $this->_p['request-id'] : $this->_requestId;
        $url .= '?request-id='. $request_id;

        // Initialization of cURL
        $ch = curl_init( $url );

        // Set of HTTP header
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array( neccsNal_Config::CONTENT_TYPE_JSON ) );

        // In the case of calls to the WIM API, the BASIC authentication
        if( $this->_nalConf['api_type'] === neccsNal_Config::API_TYPE_NAL ) {
            curl_setopt( $ch, CURLOPT_USERPWD, neccsNal_Config::BASIC_AUTH_ID . ":" . neccsNal_Config::BASIC_AUTH_PW );
        }

        curl_setopt($ch, CURLOPT_HTTPGET, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt( $ch, CURLOPT_TIMEOUT, neccsNal_Config::CURL_TIMEOUT );

        $tenantList = curl_exec( $ch );

        $info = curl_getinfo($ch);
        $http_status = $info['http_code'];

        curl_close( $ch );

        // Output log
        $this->logit( neccsNal_Config::SUCCESS_CODE, "API success ($url)", array( 'request_id' => $request_id ), $tenantList );

        $tenantList = json_decode( $tenantList, true );

        if( empty( $tenantList ) ){
            return;
        }

        // ( array( id => tenant_name ) )
        $tenantNameList = array();
        foreach( $tenantList as $list){
            $tenantInfo = json_decode( $list['tenant_info'], true );
            if( !empty( $tenantInfo ) ){
                $result[$tenantInfo[0]['id']]['tenant_name']    = $list['tenant_name'];
                $result[$tenantInfo[0]['id']]['IaaS_tenant_id'] = $list['IaaS_tenant_id'];
                $result[$tenantInfo[0]['id']]['ID']             = $list['ID'];
            }
        }

        return $result;

    }
}
