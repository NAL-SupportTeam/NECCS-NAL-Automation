<?php
#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#
/**
 * 1.SYSTEM   : API Controller
 * 2.FUNCTION : globalip_return.php (Individual method)
 */
require_once dirname(__FILE__). '/../Nal.php';

class globalip_return extends neccsNal {

    /**
     * PUT method (Reimburse the global IP address)
     *
     */
    protected function put() {

        // IaaS_tenant_id
        if( isset( $this->_p['IaaS_tenant_id'] ) ) {
            $IaaSTenantId = $this->_p['IaaS_tenant_id'];
        } else {
            $this->error( neccsNal_Config::PARAMETER_ERROR, "IaaS_tenant_id is not set." );
        }

        // global ip address
        if( isset( $this->_p['global_ip'] ) ) {
            $globalIp = $this->_p['global_ip'];
        } else {
            $this->error( neccsNal_Config::PARAMETER_ERROR, "global_ip is not set." );
        }

        // Convert the tenant ID
        $this->_p['tenant_name'] = $this->_getTenant( $IaaSTenantId );

        // Failure to convert the tenant ID
        if( empty( $this->_p['tenant_name'] ) ) {
            $this->error( neccsNal_Config::PARAMETER_ERROR, "Failed to convert the tenant ID." );
        }

        // Create a URL (Referring to the global IP address)
        $url  = neccsNal_Config::API_URL;
        $url .= neccsNal_Config::API_URL_LIST;
        $url .= neccsNal_Config::$setReferResource[neccsNal_Config::GLOBALIP];
        $url .= '?' . 'tenant_name=' . $this->_p['tenant_name'];
        $url .= '&' . 'global_ip=' . $globalIp;
        $url .= '&' . 'status=201';
        $url .= '&' . 'delete_flg=' . '0';
        $request_id = isset( $this->_p['request-id'] ) ? $this->_p['request-id'] : $this->_requestId;
        $url .= '&' . 'request-id=' . $request_id;

        // Referring to the global IP address
        $globalIpInfo = array();
        $globalIpInfo = $this->_execApiHttpMethod( $url, '', '', neccsNal_Config::HTTP_GET );

        // If the global IP address information can not be acquired
        if( empty( $globalIpInfo ) ) {
            $this->error( neccsNal_Config::REST_API_ERROR, "global ip not exists. ($globalIp)" );
        }

        // Create a URL (Reimburse the global IP address)
        $url  = neccsNal_Config::API_URL;
        $url .= neccsNal_Config::API_URL_LIST;
        $url .= neccsNal_Config::$setReferResource[neccsNal_Config::GLOBALIP] . '/';
        $url .= $globalIpInfo[0]['ID']; // Key to be updated

        // Update parameters
        $param               = array();
        $param['update_id']  = isset( $this->_p['operation_id'] ) ? $this->_p['operation_id'] : '';
        $param['status']     = '203'; // Refunds
        $param['tenant_name']  = '';
        $param['node_id']  = '';
        $request_id = isset( $this->_p['request-id'] ) ? $this->_p['request-id'] : $this->_requestId;
        $param['request-id'] = $request_id;

        // To update the global IP address
        $result = $this->_execApi( $url, $param );

        // It outputs the result
        $this->success( $result );
    }
}