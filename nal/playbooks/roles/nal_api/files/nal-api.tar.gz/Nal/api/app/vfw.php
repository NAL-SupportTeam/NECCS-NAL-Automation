<?php
#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#
/**
 * 1.SYSTEM   : API Controller
* 2.FUNCTION : vfw.php (Individual method)
*/
require_once dirname(__FILE__). '/../Nal.php';

class vfw extends neccsNal {

    /**
     * GET method (list,refer)
     *
     */
    protected function get() {

        $url  = neccsNal_Config::API_URL;
        $url .= neccsNal_Config::API_URL_LIST;
        $url .= neccsNal_Config::RESOURCE_APLS;
        $url .= '?' . 'ID=' . $this->_p['ID'];
        $url .= '&' . 'delete_flg=' . '0';
        $request_id = isset( $this->_p['request-id'] ) ? $this->_p['request-id'] : $this->_requestId;
        $url .= '&' . 'request-id=' . $request_id;

        // Referring to the global IP address
        $aplIpInfo = array();
        $aplIpInfo = $this->_execApiHttpMethod( $url, '', '', neccsNal_Config::HTTP_GET );

        if( empty( $aplIpInfo ) ){

            $result['vnf_info'] = array();
            $result['port_info'] = array();

        }else{

            $result['vnf_info'] = $aplIpInfo;

            if( !empty( $aplIpInfo[0]['node_id'] ) ){

                unset( $this->_p['ID'] );
                $this->_p['node_id'] = $aplIpInfo[0]['node_id'];

                // Create a URL
                $url = $this->_setUrl();

                // Run the API
                $result['port_info'] = $this->_execApi( $url );

            } else {

                $result['port_info'] = array();

            }

        }

        // It outputs the result
        $this->success( $result );

    }
}
