<?php
#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#
/**
 * 1.SYSTEM   : API Controller
* 2.FUNCTION : cpu_detail.php (Individual method)
*/
require_once dirname(__FILE__). '/../Nal.php';

class cpu_detail extends neccsNal {

    protected $_usagesInfo         = array();
    protected $_tenantContractInfo = array();
    protected $_quotaInfo          = array();
    protected $_floverList         = array();

    /**
     * GET method (list,refer)
     *
     */
    protected function get() {

        // pod_id
        if( !isset( $this->_p['pod_id'] ) ) {
            $this->error( neccsNal_Config::PARAMETER_ERROR, "pod_id is not set." );
        }

        $result = array();
        // In NAL server, in the case of the NAL call
        if( $this->_nalConf['api_type'] === neccsNal_Config::API_TYPE_NAL ){

            $inParam['pod_id'] = $this->_p['pod_id'];
            // Acquisition of pod information
            $podInfo = $this->getPod( $inParam );
            $use_type = $podInfo[0]['use_type'];

            $data = array();
            $contractCntInfo = $this->_getContractCnt( $this->_p['pod_id'] );

            if( $use_type === 2 ){

                // Create a URL (Call of WIM API)
                $url = neccsNal_Config::WIM_API_URL . str_replace( '/Nal/', '', $_SERVER['REQUEST_URI'] );
                $url .= '&request-id='. $this->_p['request-id'];

                // API execution
                $result = $this->_execApi( $url );

                $status = isset( $result['result']['status'] ) ? $result['result']['status'] : '';
                if( $status === neccsNal_Config::STATUS_SUCCESS ) {
                    $data = $result['data'];
                } else {
                    $this->_execResult( $result, $url );
                }

            }
        }

        if( ( $this->_nalConf['api_type'] === neccsNal_Config::API_TYPE_NAL && !isset( $result['data']['wim_check_flg'] ) )
            || $this->_nalConf['api_type'] === neccsNal_Config::API_TYPE_WIM ){

            $inParam = array();
            if( $this->_nalConf['api_type'] === neccsNal_Config::API_TYPE_WIM ){
                $inParam['dc_id'] = neccsNal_Config::MY_DC_ID;
            } else if( $this->_nalConf['api_type'] === neccsNal_Config::API_TYPE_NAL ) {
                $inParam['dc_id'] = 'system';
            }

            $inParam['pod_id'] = $this->_p['pod_id'];
            $inParam['type'] = '1';
            // Acquisition of endpoint information
            $endpointInfo = $this->getEndpoint( $inParam );

            if( empty( $endpointInfo ) ){

                $data = array();
                $data['total_info']['quota'] = 0;
                $data['total_info']['use_cnt'] = 0;
                if ( $this->_p['function_type'] === neccsNal_Config::MEMORY_DETAIL ){
                    $data['total_info']['quota']   = '0MB';
                    $data['total_info']['use_cnt'] = '0MB';
                } else if ( $this->_p['function_type'] === neccsNal_Config::STORAGE_DETAIL ){
                    $data['total_info']['quota']   = '0GB';
                    $data['total_info']['use_cnt'] = '0GB';
                }
                $data['contract_info'] = array();

            } else {

                // Reference of OpenStack information
                $endpoint     = json_decode( $endpointInfo[0]['endpoint_info'], true );
                $tenant_name  = $endpoint['admin_tenant_name'];

                // Get the information from OpenStack
                // Memory, CPU, and storage
                $this->_usagesInfo = $this->listUsageReport( $tenant_name, $endpoint );
                $this->_quotaInfo  = $this->listHostDetail( $tenant_name, $endpoint );

                $tenantList = array();
                $tenantList = $this->_getTenantForId();

                $data = $this->setData( $tenantList );
            }

            // A flag is added because it isn't carried out twice.
            if( $this->_nalConf['api_type'] === neccsNal_Config::API_TYPE_WIM ){
                $data['wim_check_flg'] = '1';
                $this->success( $data );
            }
        }

        // A flag is added because it isn't carried out twice.
        if( $this->_nalConf['api_type'] === neccsNal_Config::API_TYPE_NAL && isset( $result['data']['wim_check_flg'] ) ){
            unset( $result['data']['wim_check_flg'] );
        }

        $data['contract_info'] = array_values ( array_merge_recursive( $data['contract_info'], $contractCntInfo ) );
        foreach( $data['contract_info'] as $key => $contract ){
            if( !isset( $contract['use_cnt'] ) ){
                $data['contract_info'][$key]['use_cnt'] = 0;
            }

            if( !isset( $contract['contract_cnt'] ) ){
                $data['contract_info'][$key]['contract_cnt'] = 0;
            }

            if ( $this->_p['function_type'] === neccsNal_Config::MEMORY_DETAIL ){
                $data['contract_info'][$key]['contract_cnt'] = $this->_setUnitForMemory( $data['contract_info'][$key]['contract_cnt'] );
                $data['contract_info'][$key]['use_cnt']      = $this->_setUnitForMemory( $data['contract_info'][$key]['use_cnt'] );
            } else if ( $this->_p['function_type'] === neccsNal_Config::STORAGE_DETAIL ){
                $data['contract_info'][$key]['contract_cnt'] = $this->_setUnitForStorage( $data['contract_info'][$key]['contract_cnt'] );
                $data['contract_info'][$key]['use_cnt']      = $this->_setUnitForStorage( $data['contract_info'][$key]['use_cnt'] );
            }
        }

        $result = $data;
        $result['contract_info'] = array_values( $data['contract_info'] );

        $url = neccsNal_Config::NAL_API_URL . str_replace( '/Nal/', '', $_SERVER['REQUEST_URI'] );
        $this->logit( neccsNal_Config::SUCCESS_CODE, "OutPut Data ( $url )", $this->_p, $result );

        // It outputs the result
        $this->success( $result );
    }

    /**
     * Get the tenant_name that brute string to id
     *
     * @return Tenant Information
     */
    protected function _getTenantForId(){

        $url = neccsNal_Config::API_URL . neccsNal_Config::API_URL_LIST . neccsNal_Config::RESOURCE_TENANTS;
        $request_id = isset( $this->_p['request-id'] ) ? $this->_p['request-id'] : $this->_requestId;
        $url .= '?request-id='. $request_id;

        // Initialization of cURL
        $ch = curl_init( $url );

        // Set of HTTP header
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array( neccsNal_Config::CONTENT_TYPE_JSON ) );

        // In the case of calls to the WIM API, the BASIC authentication
        if( $this->_nalConf['api_type'] === neccsNal_Config::API_TYPE_NAL ) {
            curl_setopt( $ch, CURLOPT_USERPWD, neccsNal_Config::BASIC_AUTH_ID . ":" . neccsNal_Config::BASIC_AUTH_PW );
        }

        curl_setopt($ch, CURLOPT_HTTPGET, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt( $ch, CURLOPT_TIMEOUT, neccsNal_Config::CURL_TIMEOUT );

        $tenantList = curl_exec( $ch );

        $info = curl_getinfo($ch);
        $http_status = $info['http_code'];

        curl_close( $ch );

        // Output log
        $this->logit( neccsNal_Config::SUCCESS_CODE, "API success ($url)", array( 'request_id' => $request_id ), $tenantList );

        $tenantList = json_decode( $tenantList, true );

        if( empty( $tenantList ) ){
            return;
        }

        // ( array( id => tenant_name ) )
        $tenantNameList = array();
        foreach( $tenantList as $list){
            $tenantInfo = json_decode( $list['tenant_info'], true );
            if( empty( $tenantInfo ) ){
                continue;
            }
            $result[$tenantInfo[0]['id']]['tenant_name']    = $list['tenant_name'];
            $result[$tenantInfo[0]['id']]['IaaS_tenant_id'] = $list['IaaS_tenant_id'];
            $result[$tenantInfo[0]['id']]['ID']             = $list['ID'];
        }

        return $result;

    }

    /**
     * Return of the response
     *
     * @param Execution result
     * @param URL
     */
    protected function _execResult( $result, $url ) {

        // If the API execution result contains the "result", the result is output directly
        if ( array_key_exists( 'result', $result ) ) {

            // Get the error code
            $code = $result['result']['error-code'];
            if( in_array( $code, neccsNal_Config::$successApiCode ) ){
                // Output log
                $this->logit( neccsNal_Config::SUCCESS_CODE, "WIM API success ( $url )", $this->_p, $result );
                // In the case of error
            }else if( in_array( $code, neccsNal_Config::$errorApiCode ) ){
                $errMsg = $result['result']['message'];
                // Output log
                $this->logit($code, $errMsg , '', $result);
            }

            // If you are running the test, return only message
            if( defined( 'PHPUNIT_RUN' ) ){
                throw new Exception( $result['result']['message'] );
            }

            // Return of the response
            header( "HTTP/1.1 200" );
            header( neccsNal_Config::CONTENT_TYPE_JSON );
            print json_encode( $result );
            exit(0);
        }
    }

    /**
     * Acquire the number of contracts
     *
     * @param pod_id
     *
     * @return Tenant Information
     */
    protected function _getContractCnt( $pod_id ){

        // get the tenant contract
        $inParam = array();
        $inParam['contract_kind'] = '2';
        $inParam['apl_type']         = '1';
        $tenantContractInfo = $this->getTenantContract( $inParam );

        // get the DB information
        $inParam = array();
        $inParam['type']       = '5';
        $inParam['no_wim_flg'] = '1';
        $inParam['dc_id']      = 'system';
        // get the config
        $confInfo = array();
        $floverList = array();
        $confInfo = $this->getConfig( $inParam );

        if( empty( $confInfo ) ){
            return array();
        }

        $confInfo = json_decode( $confInfo[0]['config_info'], true );
        $floverList = $confInfo['os_image_and_flavor_name_list'];

        $inParam = array();
        $inParam['pod_id'] = $pod_id;
        $inParam['type'] = '1';
        // Acquisition of endpoint information
        $endpointInfo = $this->getEndpoint( $inParam );

        if( empty( $endpointInfo ) ){
            return array();
        }

        // Reference of OpenStack information
        $endpoint     = json_decode( $endpointInfo[0]['endpoint_info'], true );
        $tenant_name  = $endpoint['admin_tenant_name'];

        $flavorCntInfo = $this->listFlavorsDetail( $tenant_name, $endpoint );
        $floverListForCtr = $this->setFloverData( $floverList, $flavorCntInfo );

        $info = array();
        foreach( $floverListForCtr as $type => $info1 ){
            foreach( $info1 as $device_type => $total ){
                foreach( $tenantContractInfo as $key => $contract ){

                    $tenant_name = $contract['tenant_name'];
                    if( !isset( $info[$tenant_name] ) ){
                        $info[$tenant_name]['contract_cnt']   = 0;
                        $info[$tenant_name]['tenant_name']    = $tenant_name;
                        $info[$tenant_name]['IaaS_tenant_id'] = $contract['IaaS_tenant_id'];
                        $info[$tenant_name]['ID']             = $contract['ID'];
                    }

                    if( $type == $contract['type'] && $device_type == $contract['device_type'] ){
                        // set total_info
                        $info[$tenant_name]['contract_cnt'] += $floverListForCtr[$type][$device_type]['count'] * $contract['contract'];
                    }
                }
            }
        }

        return $info;

    }

    /**
     * Return of the response
     *
     * @param tenant infomation
     * @param usage information
     * @param flavor information
     *
     */
    protected function setFloverData( $floverList, $flavorCntInfo ) {

        $setFlovoerList = array();
        foreach( $floverList as $type => $info1 ){
            foreach( $info1 as $device_type => $value ){
                $name = $value['flavor_name'];

                foreach( $flavorCntInfo['flavors'] as $key => $floverCnt ){
                    if( $floverCnt['name'] === $name ){
                        // set total_info
                        if( $this->_p['function_type'] === neccsNal_Config::CPU_DETAIL ){
                            $setFlovoerList[$type][$device_type]['count'] = $floverCnt['vcpus'];
                        } else if ( $this->_p['function_type'] === neccsNal_Config::MEMORY_DETAIL ){
                            $setFlovoerList[$type][$device_type]['count'] = $floverCnt['disk'];
                        } else if ( $this->_p['function_type'] === neccsNal_Config::STORAGE_DETAIL ){
                            $setFlovoerList[$type][$device_type]['count'] = $floverCnt['ram'];
                        }
                    }
                }
            }
        }

        return $setFlovoerList;
    }

    /**
     * Return of the response
     *
     * @param tenant infomation
     * @param usage information
     * @param flavor information
     *
     */
    protected function setData( $tenantList ) {

        $result = array();
        $result['total_info']['quota'] = 0;
        $result['total_info']['use_cnt'] = 0;

        $info = array();
        ///////// In the case usage /////////
        if( !empty( $this->_usagesInfo['tenant_usages'] ) ){

            foreach( $this->_usagesInfo['tenant_usages'] as $serverList ){
                // Get the tenant_name
                $tenant_id = $serverList['tenant_id'];
                $tenant_name = isset( $tenantList[$tenant_id] ) ? $tenantList[$tenant_id]['tenant_name'] : '';

                if( $tenant_name === '' ){
                    continue;
                }

                // The initialization
                $info[$tenant_name]['use_cnt'] = 0;
                foreach( $serverList['server_usages'] as $value ){

                    // set total_info and contract_info
                    if( $this->_p['function_type'] === neccsNal_Config::CPU_DETAIL ){
                        $result['total_info']['use_cnt']   += $value['vcpus'];
                        $info[$tenant_name]['use_cnt'] += $value['vcpus'];
                    } else if ( $this->_p['function_type'] === neccsNal_Config::MEMORY_DETAIL ){
                        $result['total_info']['use_cnt']   += $value['memory_mb'];
                        $info[$tenant_name]['use_cnt'] += $value['memory_mb'];
                    } else if ( $this->_p['function_type'] === neccsNal_Config::STORAGE_DETAIL ){
                        $result['total_info']['use_cnt']   += $value['local_gb'];
                        $info[$tenant_name]['use_cnt'] += $value['local_gb'];
                    }

                }
            }
        } else {
            $info = array();
        }

        // To add to the return value to convert the associative array to normal array
        $result['contract_info'] = $info;

        ///////// In the case quota /////////
        foreach( $this->_quotaInfo as $quotaList ){

            // set total_info
            if( $this->_p['function_type'] === neccsNal_Config::CPU_DETAIL ){
                $result['total_info']['quota'] += $quotaList['cpu'];
            } else if ( $this->_p['function_type'] === neccsNal_Config::MEMORY_DETAIL ){
                $result['total_info']['quota'] += $quotaList['memory_mb'];
            } else if ( $this->_p['function_type'] === neccsNal_Config::STORAGE_DETAIL ){
                $result['total_info']['quota'] += $quotaList['disk_gb'];
            }
        }

        if ( $this->_p['function_type'] === neccsNal_Config::MEMORY_DETAIL ){
            $result['total_info']['quota']   = $this->_setUnitForMemory( $result['total_info']['quota'] );
            $result['total_info']['use_cnt'] = $this->_setUnitForMemory( $result['total_info']['use_cnt'] );
        } else if ( $this->_p['function_type'] === neccsNal_Config::STORAGE_DETAIL ){
            $result['total_info']['quota']   = $this->_setUnitForStorage( $result['total_info']['quota'] );
            $result['total_info']['use_cnt'] = $this->_setUnitForStorage( $result['total_info']['use_cnt'] );
        }

        return $result;
    }

}
