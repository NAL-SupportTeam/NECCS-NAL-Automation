<?php
 /* 1.SYSTEM   : OpenG
 * 2.FUNCTION : OpenStack Client nova_flavor処理クラス
 *
 * @version $Id: OscFlavors.php 2016-03-03 $
 */
require_once dirname(__FILE__). '/NovaServiceCatalog.php';
require_once dirname(__FILE__). '/../base/OscClientBase.php';
require_once dirname(__FILE__). '/../KeyStoneClient/OscTokens.php';

class OscFlavors extends OscClientBase{

    // get endpoint
    public static function getEndpoints($tenantName=null, $tenantId=null, $endpoint=array()){

        $tokens = new OscTokens();

        // endpoint
        if( !empty( $endpoint ) ){
            $userId       = $endpoint['user_id'];
            $userPassword = $endpoint['user_password'];
            $endPoint     = $endpoint['endpoint'];
        }else{
            $userId       = neccsNal_Config::$userId;
            $userPassword = neccsNal_Config::$userPassword;
            $endPoint     = neccsNal_Config::$endPoint;
        }

        $tokenId = $tokens->createToken($userId, $userPassword, $endPoint);
        $endPointArray =$tokens->getEndpoints($tokenId, $userId, $userPassword, $tenantName, $tenantId, $endPoint);

        return $endPointArray;
    }

    /**
     * フレーバー一覧参照（詳細）
     */
    public function listFlavorsDetail($endPointArray) {

        //REST API インスタンス作成
        $OscRest = new OscRest();

        $resp = array();

        //引数確認
        if ( empty( $endPointArray ) ) {
            throw new Exception( OscConst::Exception_message(__METHOD__, OscConst::Exce_Message_01, ''));
        }

        //トークン取得
        $token_id = OscCommon::getTokenId($endPointArray);

        //endpoint取得
        $url = NovaServiceCatalog::getNovaEndpoint($endPointArray);

        //endpointが存在するかのチェック
        if ( empty($url) ){
            //endpointが無い場合は、権限無しとしてErrorメッセージを返す
            throw new Exception( OscConst::Exception_message(__METHOD__, OscConst::Exce_Message_08, ''));
        }

        //REST URL作成
        $url .= '/flavors/detail';

        try{
            // REST実行
            $resp = $OscRest->rest_get($url, $token_id, array() );

        } catch ( Exception $e ) {
            throw new Exception( OscConst::Exception_message(__METHOD__, OscConst::Exce_Message_02, $e),  $e->getCode(), $e);
        }

        //OpenStack返却値チェック
        if( !(is_array($resp) && array_key_exists('flavors', $resp)) ) {
            throw new Exception( OscConst::Exception_message(__METHOD__, OscConst::Exce_Message_12, (is_array($resp) ? json_encode($resp) : $resp)));
        }

        return $resp;
    }
}
?>
