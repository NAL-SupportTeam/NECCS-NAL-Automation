<?php

class message_Config {

    public static $valiMsg = array(
        "file"            => "A file doesn't exist. ( %FILE% )",
        "json"            => "A json file couldn't be decoded.  ( %FILE% )",
        "require"         => "Please enter the %KEY%.",
        "min"             => "Please input %KEY% more than %MIN% character.",
        "max"             => "Please input %KEY% within %MAX% character.",
        "format"          => "Please check the format of %KEY%."
    );
}