<?php
#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#
/**
 * 1.SYSTEM   : API Controller
* 2.FUNCTION : all_node.php (Individual method)
*/
require_once dirname(__FILE__). '/../Nal.php';

class all_node extends neccsNal {

    /**
     * GET method (list,refer)
     *
     */
    protected function get() {

        // Create a URL
        $url = $this->_setUrl();

        // Run the API
        $result = $this->_execApi( $url );

        // It outputs the result
        $this->success( $result );
    }

}
