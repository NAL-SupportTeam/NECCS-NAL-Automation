<?php
#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#
/**
 * 1.SYSTEM   : API Controller
 * 2.FUNCTION : Index.php
 */
ini_set('display_errors', 1 );

$homeDir = realpath( dirname(__FILE__) );

define( 'HOME_DIR', $homeDir );
define( 'API_DIR' , HOME_DIR . '/api' );
define( 'APP_DIR' , HOME_DIR . '/api/app' );
define( 'VALI_DIR' , HOME_DIR . '/api/Nal/parameterCheck' );

require API_DIR . '/Nal.php';
$obj = neccsNal::getInstance();
$obj->run();

exit(0);
