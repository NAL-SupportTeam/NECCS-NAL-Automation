<?php
/**
 * 1.SYSTEM   : OpenG
 * 2.FUNCTION : OpenStack Client Keystone_token
 *
 * @version $Id: tokens.php 2012-11-27$
 */
require_once dirname(__FILE__). '/../conf/OscConst.php';
require_once dirname(__FILE__). '/../lib/OscCommon.php';
require_once dirname(__FILE__). '/../lib/OscRest.php';

class OscClientBase {
}
?>
