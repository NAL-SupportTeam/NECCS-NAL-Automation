# -*- coding: utf-8 -*-

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#
import inspect
import json

from job.tool.stubs.soap.msa import base


class OrderCommandWS(base.MsaStubBase):

    def executeCommand(self, **params):

        object_params = json.loads(params['objectParameters'])
        object_params_key = object_params.keys()

        for key in object_params_key:
            object_file_name = key

        function_name = inspect.currentframe().f_code.co_name + \
                        object_file_name + params['commandName']

        # Parse XML(Stub)
        stub_xml = self.parse_stub_xml(__class__.__name__, function_name)

        # Set Parameters To Assertion File
        result = self.set_params_for_assertion(params, stub_xml)

        return result
