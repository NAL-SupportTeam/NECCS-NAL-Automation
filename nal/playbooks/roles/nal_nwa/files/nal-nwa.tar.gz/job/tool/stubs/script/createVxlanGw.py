# -*- coding: utf-8 -*-

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#
import os
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/../../../../')
from job.tool.stubs import common


stub_common = common.StubCommon()

argv = sys.argv
script_name = stub_common.get_script_name(argv[0])

output_params = []
output_params.append(script_name)
output_params.append('| id | ' + stub_common.gen_rand_str_hex(32) + ' |')

stub_common.add_script_output_params_to_file(script_name, output_params)

for output in output_params:
    print(output)

exit(0)
