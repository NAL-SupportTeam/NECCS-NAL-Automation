# -*- coding: utf-8 -*-

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#
import inspect

from job.tool.stubs.soap.msa import base


class DeviceConfigurationWS(base.MsaStubBase):

    def attachFilesToDevice(self, **params):

        # Parse XML(Stub)
        stub_xml = self.parse_stub_xml(__class__.__name__,
                                    inspect.currentframe().f_code.co_name)

        # Set Parameters To Assertion File
        result = self.set_params_for_assertion(params, stub_xml)

        return result

    def detachFilesFromDevice(self, **params):

        # Parse XML(Stub)
        stub_xml = self.parse_stub_xml(__class__.__name__,
                                    inspect.currentframe().f_code.co_name)

        # Set Parameters To Assertion File
        result = self.set_params_for_assertion(params, stub_xml)

        return result
