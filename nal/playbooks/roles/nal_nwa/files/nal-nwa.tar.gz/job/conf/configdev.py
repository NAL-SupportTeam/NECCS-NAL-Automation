# -*- coding: utf-8 -*-

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#


class JobConfigDev:

    """JOB Config For Local Environment/Integrated Environment(Internal)."""

    # Difinition For Log
    LOG_OUTPUT_PASS = 'C:/var/log/nal/nal_job.log'
    LOG_LEVEL = 'DEBUG'

    # Definition For ScriptClient
    SCRIPT_DIR = 'C:/ICF_AutoCapsule_disabled/gitrepo/nal/job/tool/stubs'\
                                                                + '/script'
    SCRIPT_SHEBANG = 'python'
    SCRIPT_SHEBANG_PYTHON = 'python'
    SCRIPT_EXTENSION = '.py'
    SCRIPT_PARAM_ENCLOSURE = '"'
    SCRIPT_STDOUT_SEPARATER = '\r\n'

    # Definition For DB Client(RestAPI)
    REST_ENDPOINT = 'http://localhost:8081/index.py/'

    # Difinition For Template Directory
    TEMPLATE_DIR = 'C:/ICF_AutoCapsule_disabled/gitrepo/nal/job/template'
