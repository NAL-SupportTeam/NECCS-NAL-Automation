# -*- coding: utf-8 -*-

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#


class JobConfigRel:

    """JOB Config For Integrated Environment(External)."""

    # Definition For Log
    LOG_OUTPUT_PASS = '/var/log/nal/nal_automation_trace.log'
    LOG_LEVEL = 'INFO'

    # Definition For ScriptClient
    SCRIPT_DIR = '/home/nsumsmgr/NAL/nwa/job/lib/script'
    SCRIPT_DIR += '/script'
    SCRIPT_SHEBANG = 'sh'
    SCRIPT_SHEBANG_PYTHON = '/usr/bin/python2'
    SCRIPT_EXTENSION = '.sh'
    SCRIPT_PARAM_ENCLOSURE = "'"
    SCRIPT_STDOUT_SEPARATER = '\n'

    # Definition For DB Client(RestAPI)
    REST_ENDPOINT = 'http://10.169.11.3/rest/api/index.py/'

    # Difinition For Template Directory
    TEMPLATE_DIR = '/home/nsumsmgr/NAL/nwa/job/template'
