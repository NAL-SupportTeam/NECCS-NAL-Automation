# -*- coding: utf-8 -*-

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#
import json

from job.lib import logger
from urllib import parse
from urllib import request


class OscRest:

    # HTTP METHOD
    METHOD_GET = 'GET'
    METHOD_POST = 'POST'
    METHOD_PUT = 'PUT'
    METHOD_DELETE = 'DELETE'

    CONTENT_TYPE = 'application/json'

    def __init__(self, api_config_instance):
        self.logger = logger.LibLogger(api_config_instance)
        self.char_code = api_config_instance.CHAR_SET

    def rest_get(self, url, token,
                 post_params={}, query_params={}, passwords=[]):

        return self.__execute(self.METHOD_GET,
                        url, token, post_params, query_params, passwords)

    def rest_post(self, url, token,
                 post_params={}, query_params={}, passwords=[]):

        return self.__execute(self.METHOD_POST,
                        url, token, post_params, query_params, passwords)

    def rest_put(self, url, token,
                 post_params={}, query_params={}, passwords=[]):

        return self.__execute(self.METHOD_PUT,
                        url, token, post_params, query_params, passwords)

    def rest_delete(self, url, token,
                 post_params={}, query_params={}, passwords=[]):

        return self.__execute(self.METHOD_DELETE,
                        url, token, post_params, query_params, passwords)

    def __execute(self, http_method, url, token,
                        post_params, query_params, passwords):

        if len(url) == 0:
            raise SystemError('url required')

        if len(query_params) > 0:
            url += '?' + parse.urlencode(query_params)

        if post_params == None:
            request_body = ''
        else:
            request_body = json.dumps(post_params)

        request_body = request_body.encode(self.char_code)

        http_header = {
            'Content-Type': self.CONTENT_TYPE,
            'Content-Length': str(len(request_body))
        }

        if len(token) > 0:
            http_header['X-Auth-Token'] = token

        # Output Log(OpenStack Request)
        log_msg = '[OpenStack Request]'
        log_msg += '[METHOD]' + http_method
        log_msg += '[URL]' + url
        log_msg += '[HEADER]' + json.dumps(http_header)
        log_msg += '[PARAMS]' + json.dumps(post_params)
        self.logger.log_info(__name__, log_msg, passwords)

        req = request.Request(url, headers=http_header, data=request_body)
        req.method = http_method

        with request.urlopen(req) as res:
            response_params = res.read().decode(self.char_code)

        # Output Log(OpenStack Response)
        log_msg = '[OpenStack Response]'
        log_msg += '[STATUS]' + str(res.getcode())
        log_msg += '[PARAMS]' + response_params
        self.logger.log_info(__name__, log_msg, passwords)

        if len(response_params) > 0:
            response_params = json.loads(response_params)

        return response_params
