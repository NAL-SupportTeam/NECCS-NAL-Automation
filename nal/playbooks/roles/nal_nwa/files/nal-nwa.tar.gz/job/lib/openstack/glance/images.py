# -*- coding: utf-8 -*-

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#

from job.lib.openstack.glance import base


class OscGlanceImages(base.OscGlanceBase):

    def list_images(self, endpoint_array):

        # Check Input Parameters
        if len(endpoint_array) == 0:
            raise SystemError(self.EXCEPT_MSG01)

        # Get Token ID
        token_id = self.get_token_id(endpoint_array)

        # Get Endpoint URL
        url = self.get_endpoint(endpoint_array)

        # Set Parameters(Rest)
        url += '/v2.0/images'

        # Execute Rest
        resp = self.rest.rest_get(url, token_id)

        # Check Response From OpenStack
        if 'images' not in resp:
            raise SystemError(self.EXCEPT_MSG12)

        return resp
