# -*- coding: utf-8 -*-

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#
from job.lib.openstack.keystone import base


class OscTokens(base.OscKeystoneBase):

    def create_token(self, user_name, password, endpoint_url):

        # Check Input Parameters
        if len(user_name) == 0 or len(password) == 0:
            raise SystemError(self.EXCEPT_MSG01)

        # Set Parameters(Rest)
        url = endpoint_url + '/tokens'
        param = {'auth': {'passwordCredentials':
                      {'username': user_name, 'password': password}}}

        # Execute Rest
        passwords = self.utils.json_encode_passwords([password])
        resp = self.rest.rest_post(url, '', param, {}, passwords)

        # Check Response From OpenStack
        if 'access' not in resp:
            raise SystemError(self.EXCEPT_MSG12)

        # Get Token ID
        token_id = self.get_token_id(resp)

        return  token_id

    def get_endpoints(self, endpoint_url, token_id, user_name, password,
                                        tenant_name='', tenant_id=''):

        # Check Input Parameters
        if len(token_id) == 0 or len(
                user_name) == 0 or len(
                    password) == 0 or (
                            len(tenant_name) == 0 and len(tenant_id) == 0):

            raise SystemError(self.EXCEPT_MSG01)

        # Set Parameters(Rest)
        url = endpoint_url + '/tokens'
        param = {'auth': {'passwordCredentials':
                      {'username': user_name, 'password': password}}}

        if len(tenant_name) > 0:
            param['auth']['tenantName'] = tenant_name

        if len(tenant_id) > 0:
            param['auth']['tenantId'] = tenant_id

        # Execute Rest
        passwords = self.utils.json_encode_passwords([password])
        resp = self.rest.rest_post(url, token_id, param, {}, passwords)

        # Check Response From OpenStack
        if 'access' not in resp:
            raise SystemError(self.EXCEPT_MSG12)

        return resp
