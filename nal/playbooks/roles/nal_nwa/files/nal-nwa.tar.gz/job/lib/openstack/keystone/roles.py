# -*- coding: utf-8 -*-

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#
from job.lib.openstack.keystone import base


class OscRoles(base.OscKeystoneBase):

    def list_roles(self, endpoint_array):

        # Check Input Parameters
        if len(endpoint_array) == 0:
            raise SystemError(self.EXCEPT_MSG01)

        # Get Token ID
        token_id = self.get_token_id(endpoint_array)

        # Get Endpoint URL
        url = self.get_endpoint(endpoint_array)

        # Set Parameters(Rest)
        url += '/OS-KSADM/roles'

        # Execute Rest
        resp = self.rest.rest_get(url, token_id)

        # Check Response From OpenStack
        if 'roles' not in resp:
            raise SystemError(self.EXCEPT_MSG12)

        return resp

    def list_roles_for_user(self, endpoint_array, user_id, tenant_id):

        # Check Input Parameters
        if len(endpoint_array) == 0 or len(
                                    user_id) == 0 or len(tenant_id) == 0:
            raise SystemError(self.EXCEPT_MSG01)

        # Get Token ID
        token_id = self.get_token_id(endpoint_array)

        # Get Endpoint URL
        url = self.get_endpoint(endpoint_array)

        # Set Parameters(Rest)
        url += '/tenants/' + tenant_id + '/users/' + user_id + '/roles'

        # Execute Rest
        resp = self.rest.rest_get(url, token_id)

        # Check Response From OpenStack
        if 'roles' not in resp:
            raise SystemError(self.EXCEPT_MSG12)

        return resp

    def add_role_to_user(self, endpoint_array, user_id, tenant_id, role_id):

        # Check Input Parameters
        if len(endpoint_array) == 0 or len(
                user_id) == 0 or len(tenant_id) == 0 or len(role_id) == 0:
            raise SystemError(self.EXCEPT_MSG01)

        # Get Token ID
        token_id = self.get_token_id(endpoint_array)

        # Get Endpoint URL
        url = self.get_endpoint(endpoint_array)

        # Set Parameters(Rest)
        url += '/tenants/' + tenant_id + '/users/' + user_id
        url += '/roles/OS-KSADM/' + role_id

        querys = {
            'X-Auth-Token': token_id,
            'fomat': 'json',
        }

        params = {
            'tenant_id': tenant_id,
            'user_id': user_id,
            'role_id': role_id,
        }

        # Execute Rest
        resp = self.rest.rest_put(url, token_id, params, querys)

        # Check Response From OpenStack
        if 'role' not in resp:
            raise SystemError(self.EXCEPT_MSG12)

        return resp

    def remove_role_from_user(self,
                            endpoint_array, user_id, tenant_id, role_id):

        # Check Input Parameters
        if len(endpoint_array) == 0 or len(
                user_id) == 0 or len(tenant_id) == 0 or len(role_id) == 0:
            raise SystemError(self.EXCEPT_MSG01)

        # Get Token ID
        token_id = self.get_token_id(endpoint_array)

        # Get Endpoint URL
        url = self.get_endpoint(endpoint_array)

        # Set Parameters(Rest)
        url += '/tenants/' + tenant_id + '/users/' + user_id
        url += '/roles/OS-KSADM/' + role_id

        # Execute Rest
        resp = self.rest.rest_delete(url, token_id)

        # Check Response From OpenStack
        if resp != None and len(resp) > 0:
            raise SystemError(self.EXCEPT_MSG12)

        return resp
