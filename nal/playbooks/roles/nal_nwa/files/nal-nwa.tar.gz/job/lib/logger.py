# -*- coding: utf-8 -*-

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#
import logging


class LibLogger():

    def __init__(self, job_config,
                                request_id='-',
                                operation_id='-',
                                IaaS_tenant_id='-',
                                nal_tenant_id='-'):

        self.log_pass_mask = job_config.LOG_PASSWORD_MASK
        log_fmt = '%(asctime)s.%(msecs)03d %(levelname)s %(name)s ' + \
                  '[' + request_id + '] %(message)s'
        logging.basicConfig(
                            format=log_fmt,
                            filename=job_config.LOG_OUTPUT_PASS,
                            level=getattr(logging, job_config.LOG_LEVEL, 0),
                            datefmt=job_config.LOG_DATETIME_FORMAT)

    def __mask_password(self, msg, passwords):
        for val in passwords:
            if len(val) > 0:
                msg = msg.replace(val, self.log_pass_mask)
        return msg

    def log_debug(self, logger, msg, passwords=[]):
        LOG = logging.getLogger(logger)
        msg = self.__mask_password(msg, passwords)
        LOG.debug(msg)

    def log_info(self, logger, msg, passwords=[]):
        LOG = logging.getLogger(logger)
        msg = self.__mask_password(msg, passwords)
        LOG.info(msg)

    def log_warn(self, logger, msg):
        LOG = logging.getLogger(logger)
        LOG.warn(msg)

    def log_error(self, logger, msg):
        LOG = logging.getLogger(logger)
        LOG.error(msg)

    def log_fatal(self, logger, msg):
        LOG = logging.getLogger(logger)
        LOG.fatal(msg)
