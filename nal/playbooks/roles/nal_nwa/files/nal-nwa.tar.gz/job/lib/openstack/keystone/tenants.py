# -*- coding: utf-8 -*-

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#
from job.lib.openstack.keystone import base


class OscTenants(base.OscKeystoneBase):

    def list_tenants(self, endpoint_array):

        # Check Input Parameters
        if len(endpoint_array) == 0:
            raise SystemError(self.EXCEPT_MSG01)

        # Get Token ID
        token_id = self.get_token_id(endpoint_array)

        # Get Endpoint URL
        url = self.get_endpoint(endpoint_array)

        # Set Parameters(Rest)
        url += '/tenants'

        # Execute Rest
        resp = self.rest.rest_get(url, token_id)

        # Check Response From OpenStack
        if 'tenants' not in resp:
            raise SystemError(self.EXCEPT_MSG12)

        return resp

    def get_tenant(self, endpoint_array, tenant_id):

        # Check Input Parameters
        if len(endpoint_array) == 0:
            raise SystemError(self.EXCEPT_MSG01)

        # Get Token ID
        token_id = self.get_token_id(endpoint_array)

        # Get Endpoint URL
        url = self.get_endpoint(endpoint_array)

        # Set Parameters(Rest)
        url += '/tenants/' + tenant_id

        # Execute Rest
        resp = self.rest.rest_get(url, token_id)

        # Check Response From OpenStack
        if 'tenant' not in resp:
            raise SystemError(self.EXCEPT_MSG12)

        return resp

    def create_tenant(self, endpoint_array, tenant_name,
                      description='', enabled=True, domain_id='default'):

        # Check Input Parameters
        if len(endpoint_array) == 0 or len(tenant_name) == 0:
            raise SystemError(self.EXCEPT_MSG01)

        # Get Token ID
        token_id = self.get_token_id(endpoint_array)

        # Get Endpoint URL
        url = self.get_endpoint(endpoint_array)

        # Set Parameters(Rest)
        url += '/tenants'
        params = {
            'tenant': {
                'name': tenant_name,
                'description': description,
                'enabled': enabled,
                'domain_id': domain_id,
            }
        }

        # Execute Rest
        resp = self.rest.rest_post(url, token_id, params)

        # Check Response From OpenStack
        if 'tenant' not in resp:
            raise SystemError(self.EXCEPT_MSG12)

        return resp

    def update_tenant(self, endpoint_array, tenant_id,
            tenant_name='', description=None, enabled='', domain_id=''):

        # Check Input Parameters
        if len(endpoint_array) == 0 or len(tenant_id) == 0:
            raise SystemError(self.EXCEPT_MSG01)

        # Get Token ID
        token_id = self.get_token_id(endpoint_array)

        # Get Endpoint URL
        url = self.get_endpoint(endpoint_array)

        # Set Parameters(Rest)
        url += '/tenants/' + tenant_id
        params = {'tenant': {'id': tenant_id}}

        if len(tenant_name) > 0:
            params['tenant']['name'] = tenant_name

        if isinstance(description, str):
            params['tenant']['description'] = description

        if isinstance(enabled, bool):
            params['tenant']['enabled'] = enabled

        if len(domain_id) > 0:
            params['tenant']['domain_id'] = domain_id

        # Execute Rest
        resp = self.rest.rest_put(url, token_id, params)

        # Check Response From OpenStack
        if 'tenant' not in resp:
            raise SystemError(self.EXCEPT_MSG12)

        return resp

    def delete_tenant(self, endpoint_array, tenant_id):

        # Check Input Parameters
        if len(endpoint_array) == 0 or len(tenant_id) == 0:
            raise SystemError(self.EXCEPT_MSG01)

        # Get Token ID
        token_id = self.get_token_id(endpoint_array)

        # Get Endpoint URL
        url = self.get_endpoint(endpoint_array)

        # Set Parameters(Rest)
        url += '/tenants/' + tenant_id

        # Execute Rest
        resp = self.rest.rest_delete(url, token_id)

        # Check Response From OpenStack
        if resp != None and len(resp) > 0:
            raise SystemError(self.EXCEPT_MSG12)

        return resp
