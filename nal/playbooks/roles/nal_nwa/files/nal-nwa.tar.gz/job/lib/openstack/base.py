# -*- coding: utf-8 -*-

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#
from job.lib.common import utils
from job.lib.openstack.common import rest


class OpenstackClientBase:

    # Exception Message
    EXCEPT_MSG01 = 'error args key'
    EXCEPT_MSG02 = 'error GET REST I/F'
    EXCEPT_MSG03 = 'error POST REST I/F'
    EXCEPT_MSG04 = 'error PUT REST I/F'
    EXCEPT_MSG05 = 'error DELETE REST I/F'
    EXCEPT_MSG06 = 'error memcached of token id'
    EXCEPT_MSG07 = 'error memcached of endpoint'
    EXCEPT_MSG08 = 'error ENDPOINT was not found.'
    EXCEPT_MSG08 += ' Probably, you do not have authority.'
    EXCEPT_MSG09 = 'error OpenStack Non Response'
    EXCEPT_MSG10 = 'error memcached set'
    EXCEPT_MSG11 = 'error update quotas'
    EXCEPT_MSG12 = 'error OpenStack Abnormal Response returned'

    # Admin Role Name
    ROLE_NAME_ADMIN = 'admin'

    # Service Catalog Name
    SERVICE_CATALOG_KEYSTONE = 'keystone'
    SERVICE_CATALOG_NOVA = 'nova'
    SERVICE_CATALOG_QUANTUM = 'quantum'
    SERVICE_CATALOG_NEUTRON = 'neutron'

    ERROR_RESP_KEY = 'error'

    def __init__(self, api_config_instance):
        self.utils = utils.Utils()
        self.rest = rest.OscRest(api_config_instance)
        self.char_code = api_config_instance.CHAR_SET

    def get_token_id(self, endpoint_array):

        try:
            token_id = endpoint_array['access']['token']['id']

            if len(token_id) == 0:
                raise SystemError(self.EXCEPT_MSG06)

            return token_id

        except IndexError:
            raise SystemError(self.EXCEPT_MSG06)

        except:
            raise

    def get_endpoint(self, endpoint_array, admin_roles, catalog_names):

        admin_flg = False
        url = ''

        roles = endpoint_array['access']['user']['roles']
        catalogs = endpoint_array['access']['serviceCatalog']
        region_id = endpoint_array['region_id']

        # Judge Role
        for role in roles:
            role_name = role.get('name')
            if len(role_name) > 0 and role_name in admin_roles:
                admin_flg = True
                break

        # Get Endpoint
        for catalog in catalogs:
            if catalog['name'] in catalog_names:
                for endpoint in catalog['endpoints']:
                    if endpoint['region'] == region_id:
                        if admin_flg == True:
                            url = endpoint['adminURL']
                        else:
                            url = endpoint['publicURL']
                        break
                break

        return url
