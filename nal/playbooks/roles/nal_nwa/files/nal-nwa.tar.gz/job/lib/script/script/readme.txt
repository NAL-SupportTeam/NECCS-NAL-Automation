Initialization script List

--BIGIP_provisioning.sh             #For Production environment
--BIGIP_provisioning_Allinone.sh    #For AllInOne environment
--fortiVM_provisioning.sh           #For Production environment Pub
--fortiVM_provisioning_Ext.sh       #For Production environment Ext
--vSRX_FF_provisioning.sh           #For Production environment
--vSRX_FF_provisioning_Allinone.sh  #For AllInOne environment


fortiVM...This time, to use the fortiVM_provisioning.sh
