# -*- coding: utf-8 -*-

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#
from job.lib.db import base


class CreateClient(base.DbClientBase):

    METHOD = 'POST'

    def set_context(self, end_point, params):

        base.DbClientBase.end_point = end_point.rstrip('/')
        base.DbClientBase.method = self.METHOD
        base.DbClientBase.params = params

    def get_return_param(self):
        return self.return_param
