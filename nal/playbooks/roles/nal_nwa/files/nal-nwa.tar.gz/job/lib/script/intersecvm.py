# -*- coding: utf-8 -*-

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#
import inspect

from job.lib.script import base


class IntersecVmClient(base.ScriptClientBase):

    def __init__(self, api_config_instance):

        super().__init__(api_config_instance)
        base.ScriptClientBase.shebang = self.config.SCRIPT_SHEBANG_PYTHON

    def intersec_vm_get_rsa(self, params, passwords=[]):

        output = super().execute(
                inspect.currentframe().f_code.co_name, params, passwords)
        return output

    def intersec_vm_put_rsa(self, params, passwords=[]):

        output = super().execute(
                inspect.currentframe().f_code.co_name, params, passwords)
        return output
