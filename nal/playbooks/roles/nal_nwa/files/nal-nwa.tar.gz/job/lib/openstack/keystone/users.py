# -*- coding: utf-8 -*-

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#
from job.lib.openstack.keystone import base


class OscUsers(base.OscKeystoneBase):

    def list_users(self, endpoint_array, tenant_id=''):

        # Check Input Parameters
        if len(endpoint_array) == 0:
            raise SystemError(self.EXCEPT_MSG01)

        # Get Token ID
        token_id = self.get_token_id(endpoint_array)

        # Get Endpoint URL
        url = self.get_endpoint(endpoint_array)

        # Set Parameters(Rest)
        if len(tenant_id) > 0:
            url += '/tenants/' + tenant_id
        url += '/users'

        # Execute Rest
        resp = self.rest.rest_get(url, token_id)

        # Check Response From OpenStack
        if 'users' not in resp:
            raise SystemError(self.EXCEPT_MSG12)

        return resp

    def get_user(self, endpoint_array, user_id):

        # Check Input Parameters
        if len(endpoint_array) == 0 or len(user_id) == 0:
            raise SystemError(self.EXCEPT_MSG01)

        # Get Token ID
        token_id = self.get_token_id(endpoint_array)

        # Get Endpoint URL
        url = self.get_endpoint(endpoint_array)

        # Set Parameters(Rest)
        url += '/users/' + user_id

        # Execute Rest
        resp = self.rest.rest_get(url, token_id)

        # Check Response From OpenStack
        if 'user' not in resp:
            raise SystemError(self.EXCEPT_MSG12)

        return resp

    def create_user(self, endpoint_array, user_name, password, tenant_id,
                            email='', enabled=True, domain_id='default'):

        # Check Input Parameters
        if len(endpoint_array) == 0 or len(
            user_name) == 0 or len(password) == 0 or len(tenant_id) == 0:
            raise SystemError(self.EXCEPT_MSG01)

        # Get Token ID
        token_id = self.get_token_id(endpoint_array)

        # Get Endpoint URL
        url = self.get_endpoint(endpoint_array)

        # Set Parameters(Rest)
        url += '/users'
        params = {
            'user': {
                'name': user_name,
                'password': password,
                'tenantId': tenant_id,
                'email': email,
                'enabled': enabled,
                'domain_id': domain_id,
            }
        }

        # Execute Rest
        passwords = self.utils.json_encode_passwords([password])
        resp = self.rest.rest_post(url, token_id, params, {}, passwords)

        # Check Response From OpenStack
        if 'user' not in resp:
            raise SystemError(self.EXCEPT_MSG12)

        return resp

    def update_user(self, endpoint_array, user_id,
                    tenant_id='', user_name='',
                    email=None, password='', enabled='', domain_id=''):

        # Check Input Parameters
        if len(endpoint_array) == 0 or len(user_id) == 0:
            raise SystemError(self.EXCEPT_MSG01)

        # Get Token ID
        token_id = self.get_token_id(endpoint_array)

        # Get Endpoint URL
        url = self.get_endpoint(endpoint_array)

        # Set Parameters(Rest)
        url += '/users/' + user_id
        params = {}
        request_params = {}

        if len(tenant_id) > 0:
            params['tenantId'] = tenant_id

        if len(user_name) > 0:
            params['name'] = user_name

        if isinstance(email, str):
            params['email'] = email

        if len(password) > 0:
            params['password'] = password

        if isinstance(enabled, bool):
            params['enabled'] = enabled

        if len(domain_id) > 0:
            params['domain_id'] = domain_id

        if len(params) > 0:
            request_params['user'] = params

        # Execute Rest
        passwords = self.utils.json_encode_passwords([password])
        resp = self.rest.rest_put(
                        url, token_id, request_params, {}, passwords)

        # Check Response From OpenStack
        if 'user' not in resp:
            raise SystemError(self.EXCEPT_MSG12)

        return resp

    def update_user_enabled(self, endpoint_array, user_id, enabled):

        # Check Input Parameters
        if len(endpoint_array) == 0 or len(
                user_id) == 0 or isinstance(enabled, bool) == False:
            raise SystemError(self.EXCEPT_MSG01)

        # Get Token ID
        token_id = self.get_token_id(endpoint_array)

        # Get Endpoint URL
        url = self.get_endpoint(endpoint_array)

        # Set Parameters(Rest)
        url += '/users/' + user_id + '/OS-KSADM/enabled'
        params = {
            'user': {
                'id': user_id,
                'enabled': enabled,
            }
        }

        # Execute Rest
        resp = self.rest.rest_put(url, token_id, params)

        # Check Response From OpenStack
        if 'user' not in resp:
            raise SystemError(self.EXCEPT_MSG12)

        return resp

    def update_user_password(self, endpoint_array, user_id, password):

        # Check Input Parameters
        if len(endpoint_array) == 0 or len(
                                    user_id) == 0 or len(password) == 0:
            raise SystemError(self.EXCEPT_MSG01)

        # Get Token ID
        token_id = self.get_token_id(endpoint_array)

        # Get Endpoint URL
        url = self.get_endpoint(endpoint_array)

        # Set Parameters(Rest)
        url = url + '/users/' + user_id
        url += '/OS-KSADM/password'

        querys = {
            'X-Auth-Token': token_id,
            'fomat': 'json',
        }

        params = {
            'user': {
                'id': user_id,
                'password': password,
            }
        }

        # Execute Rest
        passwords = self.utils.json_encode_passwords([password])
        resp = self.rest.rest_put(url, token_id, params, querys, passwords)

        # Check Response From OpenStack
        if 'user' not in resp:
            raise SystemError(self.EXCEPT_MSG12)

        return resp

    def delete_user(self, endpoint_array, user_id):

        # Check Input Parameters
        if len(endpoint_array) == 0 or len(user_id) == 0:
            raise SystemError(self.EXCEPT_MSG01)

        # Get Token ID
        token_id = self.get_token_id(endpoint_array)

        # Get Endpoint URL
        url = self.get_endpoint(endpoint_array)

        # Set Parameters(Rest)
        url += '/users/' + user_id

        # Execute Rest
        resp = self.rest.rest_delete(url, token_id)

        # Check Response From OpenStack
        if resp != None and len(resp) > 0:
            raise SystemError(self.EXCEPT_MSG12)

        return resp
