# -*- coding: utf-8 -*-

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#
import inspect
import json
import traceback

from job.auto import base
from job.lib.db import list
from job.lib.db import update
from job.lib.soap.msa import bigipordercmdws


class SetupDeviceBigIp(base.JobAutoBase):

    def device_setup_create_bigip(self, job_input):

        function_name = inspect.currentframe().f_code.co_name

        # Output Log(Job Input)
        self.output_log_job_params(self.LOG_TYPE_INPUT,
                                         __name__, function_name, job_input)

        # Get JOB Input Parameters
        pod_id = job_input['pod_id']
        apl_type = job_input['apl_type']
        nf_type = job_input['type']
        device_type = job_input['device_type']
        redundant_configuration_flg = job_input['redundant_configuration_flg']
        if isinstance(redundant_configuration_flg, int):
            redundant_configuration_flg = str(redundant_configuration_flg)

        # Get DeviceID
        apl_data = self.__get_db_apl(job_input)
        master_msa_device_id = apl_data['master_MSA_device_id']
        slave_msa_device_id = apl_data['slave_MSA_device_id']

        # Get MSA Config
        msa_config_for_common = self.get_msa_config_for_common(pod_id)
        device_name = self.device_type_to_name(apl_type, nf_type, device_type)
        msa_config_for_device = \
            self.get_msa_config_for_device(pod_id, device_name)

        # Setup System Common Setting
        self.__setup_system_common_bigip(job_input,
                                             'act',
                                             pod_id,
                                             master_msa_device_id,
                                             msa_config_for_common,
                                             msa_config_for_device)
        if redundant_configuration_flg == '0':
            self.__setup_system_common_bigip(job_input,
                                                 'sby',
                                                 pod_id,
                                                 slave_msa_device_id,
                                                 msa_config_for_common,
                                                 msa_config_for_device)

        # Setup Tenant VLAN Setting
        self.__setup_tenant_vlan_bigip(job_input,
                                         'act',
                                          pod_id,
                                          master_msa_device_id,
                                          msa_config_for_common,
                                          msa_config_for_device,
                                          apl_data['nic_tenant'])
        if redundant_configuration_flg == '0':
            self.__setup_tenant_vlan_bigip(job_input,
                                             'sby',
                                              pod_id,
                                              slave_msa_device_id,
                                              msa_config_for_common,
                                              msa_config_for_device,
                                              apl_data['nic_tenant'])

        # Set JOB Output Parameters
        job_output = {}

        # Output Log(Job Output)
        self.output_log_job_params(self.LOG_TYPE_OUTPUT,
                                         __name__, function_name, job_output)

        return job_output

    def device_setup_delete_bigip(self, job_input):

        function_name = inspect.currentframe().f_code.co_name

        # Output Log(Job Input)
        self.output_log_job_params(self.LOG_TYPE_INPUT,
                                         __name__, function_name, job_input)

        # Get JOB Input Parameters
        pod_id = job_input['pod_id']
        apl_type = job_input['apl_type']
        nf_type = job_input['type']
        device_type = job_input['device_type']
        redundant_configuration_flg = job_input['redundant_configuration_flg']
        if isinstance(redundant_configuration_flg, int):
            redundant_configuration_flg = str(redundant_configuration_flg)

        # Get DeviceID
        apl_data = self.__get_db_apl(job_input)
        master_msa_device_id = apl_data['master_MSA_device_id']
        slave_msa_device_id = apl_data['slave_MSA_device_id']

        device_user_name_dict = json.loads(apl_data['device_user_name'])
        partition_id = device_user_name_dict['partition_id']
        route_domain_id = device_user_name_dict['route_domain_id']

        # Get MSA Config
        msa_config_for_common = self.get_msa_config_for_common(pod_id)
        device_name = self.device_type_to_name(apl_type, nf_type, device_type)
        msa_config_for_device = \
            self.get_msa_config_for_device(pod_id, device_name)

        # Setup Tenant VLAN Setting
        self.__unsetup_tenant_vlan_bigip(job_input,
                                         'act',
                                          pod_id,
                                          master_msa_device_id,
                                          partition_id,
                                          route_domain_id,
                                          msa_config_for_common,
                                          msa_config_for_device)
        if redundant_configuration_flg == '0':
            self.__unsetup_tenant_vlan_bigip(job_input,
                                             'sby',
                                              pod_id,
                                              slave_msa_device_id,
                                              partition_id,
                                              route_domain_id,
                                              msa_config_for_common,
                                              msa_config_for_device)

        # Setup System Common Setting
        user_mng_params_master = self.get_apl_msa_input_params(
                                        apl_data['device_detail_master'],
                                        'create_big_ip_user_manager',
                                        'BIGIP_User_Manager')

        user_crt_mng_params_master = self.get_apl_msa_input_params(
                                    apl_data['device_detail_master'],
                                    'create_big_ip_user_certificate_manager',
                                    'BIGIP_User_Certificate_Manager')

        self.__unsetup_system_common_bigip(job_input,
                                             'act',
                                             pod_id,
                                             master_msa_device_id,
                                             partition_id,
                                             route_domain_id,
                                             msa_config_for_common,
                                             msa_config_for_device,
                                        user_mng_params_master['user_id'],
                                    user_crt_mng_params_master['user_id'])

        if redundant_configuration_flg == '0':

            user_mng_params_slave = self.get_apl_msa_input_params(
                                        apl_data['device_detail_slave'],
                                        'create_big_ip_user_manager',
                                        'BIGIP_User_Manager')

            user_crt_mng_params_slave = self.get_apl_msa_input_params(
                                    apl_data['device_detail_slave'],
                                    'create_big_ip_user_certificate_manager',
                                    'BIGIP_User_Certificate_Manager')

            self.__unsetup_system_common_bigip(job_input,
                                                 'sby',
                                                 pod_id,
                                                 slave_msa_device_id,
                                                 partition_id,
                                                 route_domain_id,
                                                 msa_config_for_common,
                                                 msa_config_for_device,
                                        user_mng_params_slave['user_id'],
                                    user_crt_mng_params_slave['user_id'])

        # Set JOB Output Parameters
        job_output = {}

        # Output Log(Job Output)
        self.output_log_job_params(self.LOG_TYPE_OUTPUT,
                                         __name__, function_name, job_output)

        return job_output

    def __setup_system_common_bigip(self,
                                       job_input,
                                       act_sby,
                                       pod_id,
                                       msa_device_id,
                                       msa_config_for_common,
                                       msa_config_for_device):

        node_detail = {}

        # Create Instance(MSA Soap Client)
        msa = bigipordercmdws.BigIpOrderCommandWs(
                                                    self.job_config,
                                                    self.nal_endpoint_config,
                                                    pod_id)

        # Create Partition(MSA)
        msa_res = self.execute_msa_command(
                                    msa_config_for_device,
                                    msa,
                                    'create_big_ip_partition',
                                    msa_device_id,
                                    job_input['partition_id']
        )
        node_detail[
            'create_big_ip_partition'] = msa_res[msa.RES_KEY_IN]

        # Create RouteDomain(MSA)
        msa_res = self.execute_msa_command(
                                    msa_config_for_device,
                                    msa,
                                    'create_big_ip_route_domain',
                                    msa_device_id,
                                    job_input['partition_id'],
                                    job_input['route_domain_id']
        )
        node_detail[
            'create_big_ip_route_domain'] = msa_res[msa.RES_KEY_IN]

        # Create DefaultRouteDomain(MSA)
        msa_res = self.execute_msa_command(
                                    msa_config_for_device,
                                    msa,
                                    'create_big_ip_default_route_domain',
                                    msa_device_id,
                                    job_input['partition_id'],
                                    job_input['route_domain_id']
        )
        node_detail[
            'create_big_ip_default_route_domain'] = msa_res[msa.RES_KEY_IN]

        # Create User Manager(MSA)
        msa_res = self.execute_msa_command(
                                    msa_config_for_device,
                                    msa,
                                    'create_big_ip_user_manager',
                                    msa_device_id,
                                    job_input['partition_id'],
                                    job_input['mng_user_account_id'],
                                    'manager',
                                    job_input['mng_account_password']
        )
        node_detail[
            'create_big_ip_user_manager'] = msa_res[msa.RES_KEY_IN]

        # Create User Certificate Manager(MSA)
        msa_res = self.execute_msa_command(
                                    msa_config_for_device,
                                    msa,
                                    'create_big_ip_user_certificate_manager',
                                    msa_device_id,
                                    job_input['partition_id'],
                                    job_input['certificate_user_account_id'],
                                    'certificate-manager',
                                    job_input['certificate_account_password']
        )
        node_detail[
            'create_big_ip_user_certificate_manager'] = msa_res[msa.RES_KEY_IN]

        # Update NAL_VNF_MNG(DB)
        self.__update_db_apl(job_input, act_sby, node_detail)

    def __setup_tenant_vlan_bigip(self,
                                      job_input,
                                      act_sby,
                                      pod_id,
                                      msa_device_id,
                                      msa_config_for_common,
                                      msa_config_for_device,
                                      nic_tenant):

        msa_info = {}

        # Get JOB Input Parameters
        nal_tenant_id = job_input['nal_tenant_id']
        port_id4 = job_input['port_id4']

        # List NAL_VNF_MNG(DB Client)
        db_endpoint_port = self.get_db_endpoint(self.job_config.REST_URI_PORT)
        db_endpoint_vlan = self.get_db_endpoint(self.job_config.REST_URI_VLAN)
        db_list = list.ListClient(self.job_config)

        params = {}
        params['delete_flg'] = 0
        params['tenant_id'] = nal_tenant_id
        params['port_id'] = port_id4
        db_list.set_context(db_endpoint_port, params)
        db_list.execute()
        port_list = db_list.get_return_param()

        params = {}
        params['delete_flg'] = 0
        params['tenant_id'] = nal_tenant_id
        params['network_id'] = port_list[0]['network_id']
        db_list.set_context(db_endpoint_vlan, params)
        db_list.execute()
        vlan_list = db_list.get_return_param()

        # Create Instance(MSA Soap Client)
        msa = bigipordercmdws.BigIpOrderCommandWs(
                                                    self.job_config,
                                                    self.nal_endpoint_config,
                                                    pod_id)

        port_dict = json.loads(port_list[0]['port_info'])

        vip_ip_address = port_dict['IaaS_port_info']['vip']['ip_address']
        vip_netmask = port_dict['IaaS_port_info']['vip']['netmask']

        if act_sby == 'act':
            ip_address = port_dict['IaaS_port_info']['act']['ip_address']
            netmask = port_dict['IaaS_port_info']['act']['netmask']
        else:
            ip_address = port_dict['IaaS_port_info']['sby']['ip_address']
            netmask = port_dict['IaaS_port_info']['sby']['netmask']

        # Create VLAN(MSA Soap Client)
        msa_res = self.execute_msa_command(
            msa_config_for_device,
            msa,
            'create_big_ip_vlan',
            msa_device_id,
            job_input['partition_id'],
            job_input['partition_id'] + '_' + vlan_list[0]['vlan_id'],
            nic_tenant,
            vlan_list[0]['vlan_id']
        )
        msa_info['create_big_ip_vlan'] = msa_res[msa.RES_KEY_IN]

        # Create PhysicalIP(MSA Soap Client)
        msa_res = self.execute_msa_command(
            msa_config_for_device,
            msa,
            'create_big_ip_physical_ip',
            msa_device_id,
            job_input['partition_id'],
            job_input['partition_id'] + '_' + vlan_list[0]['vlan_id'] + '_IP',
            ip_address,
            self.utils.get_subnet_mask_from_cidr_len(netmask),
            job_input['partition_id'] + '_' + vlan_list[0]['vlan_id']
        )
        msa_info['create_big_ip_physical_ip'] = msa_res[msa.RES_KEY_IN]

        # Create VIP(MSA Soap Client)
        msa_res = self.execute_msa_command(
            msa_config_for_device,
            msa,
            'create_big_ip_vip',
            msa_device_id,
            job_input['partition_id'],
            job_input['partition_id'] + '_' + vlan_list[0]['vlan_id'] + '_VIP',
            vip_ip_address,
            self.utils.get_subnet_mask_from_cidr_len(vip_netmask),
            job_input['partition_id'] + '_' + vlan_list[0]['vlan_id'],
            'traffic-group-1'
        )
        msa_info['create_big_ip_vip'] = msa_res[msa.RES_KEY_IN]

        # Update NAL_PORT_MNG(DB)
        self.__update_db_port(job_input, act_sby, port_id4, msa_info)

    def __unsetup_system_common_bigip(self,
                                       job_input,
                                       act_sby,
                                       pod_id,
                                       msa_device_id,
                                       partition_id,
                                       route_domain_id,
                                       msa_config_for_common,
                                       msa_config_for_device,
                                       mng_user_account_id,
                                       certificate_user_account_id):

        # Create Instance(MSA Soap Client)
        msa = bigipordercmdws.BigIpOrderCommandWs(
                                                    self.job_config,
                                                    self.nal_endpoint_config,
                                                    pod_id)

        job_cleaning_mode = job_input.get('job_cleaning_mode', '0')

        try:
            # Delete User Certificate Manager(MSA)
            self.execute_msa_command(
                                    msa_config_for_device,
                                    msa,
                                    'delete_big_ip_user_certificate_manager',
                                    msa_device_id,
                                    partition_id,
                                    certificate_user_account_id
                                    )
        except:
            if job_cleaning_mode == '1':
                self.output_log_fatal(__name__, traceback.format_exc())
            else:
                raise

        try:
            # Delete User Manager(MSA)
            self.execute_msa_command(
                                    msa_config_for_device,
                                    msa,
                                    'delete_big_ip_user_manager',
                                    msa_device_id,
                                    partition_id,
                                    mng_user_account_id
                                    )
        except:
            if job_cleaning_mode == '1':
                self.output_log_fatal(__name__, traceback.format_exc())
            else:
                raise

        try:
            # Delete DefaultRouteDomain(MSA)
            self.execute_msa_command(
                                    msa_config_for_device,
                                    msa,
                                    'delete_big_ip_default_route_domain',
                                    msa_device_id,
                                    partition_id
                                    )
        except:
            if job_cleaning_mode == '1':
                self.output_log_fatal(__name__, traceback.format_exc())
            else:
                raise

        try:
            # Delete RouteDomain(MSA)
            self.execute_msa_command(
                                    msa_config_for_device,
                                    msa,
                                    'delete_big_ip_route_domain',
                                    msa_device_id,
                                    partition_id
                                    )
        except:
            if job_cleaning_mode == '1':
                self.output_log_fatal(__name__, traceback.format_exc())
            else:
                raise

        try:
            # Delete Partition(MSA)
            self.execute_msa_command(
                                    msa_config_for_device,
                                    msa,
                                    'delete_big_ip_partition',
                                    msa_device_id,
                                    partition_id
                                    )
        except:
            if job_cleaning_mode == '1':
                self.output_log_fatal(__name__, traceback.format_exc())
            else:
                raise

    def __unsetup_tenant_vlan_bigip(self,
                                      job_input,
                                      act_sby,
                                      pod_id,
                                      msa_device_id,
                                      partition_id,
                                      route_domain_id,
                                      msa_config_for_common,
                                      msa_config_for_device):

        # Get JOB Input Parameters
        nal_tenant_id = job_input['nal_tenant_id']
        node_id = job_input['node_id']
        job_cleaning_mode = job_input.get('job_cleaning_mode', '0')

        # List NAL_VNF_MNG(DB Client)
        db_endpoint_port = self.get_db_endpoint(self.job_config.REST_URI_PORT)
        db_endpoint_vlan = self.get_db_endpoint(self.job_config.REST_URI_VLAN)
        db_list = list.ListClient(self.job_config)

        params = {}
        params['delete_flg'] = 0
        params['tenant_id'] = nal_tenant_id
        params['node_id'] = node_id
        db_list.set_context(db_endpoint_port, params)
        db_list.execute()
        port_list = db_list.get_return_param()

        params = {}
        params['delete_flg'] = 0
        params['tenant_id'] = nal_tenant_id
        params['network_id'] = port_list[0]['network_id']
        db_list.set_context(db_endpoint_vlan, params)
        db_list.execute()
        vlan_list = db_list.get_return_param()
        vlan_id = vlan_list[0]['vlan_id']

        # Create Instance(MSA Soap Client)
        msa = bigipordercmdws.BigIpOrderCommandWs(
                                                    self.job_config,
                                                    self.nal_endpoint_config,
                                                    pod_id)

        try:
            # Delete VIP(MSA Soap Client)
            self.execute_msa_command(
                msa_config_for_device,
                msa,
                'delete_big_ip_vip',
                msa_device_id,
                partition_id,
                partition_id + '_' + vlan_id + '_VIP'
            )
        except:
            if job_cleaning_mode == '1':
                self.output_log_fatal(__name__, traceback.format_exc())
            else:
                raise

        try:
            # Delete PhysicalIP(MSA Soap Client)
            self.execute_msa_command(
                msa_config_for_device,
                msa,
                'delete_big_ip_physical_ip',
                msa_device_id,
                partition_id,
                partition_id + '_' + vlan_id + '_IP'
            )
        except:
            if job_cleaning_mode == '1':
                self.output_log_fatal(__name__, traceback.format_exc())
            else:
                raise

        try:
            # Delete VIP(MSA Soap Client)
            self.execute_msa_command(
                msa_config_for_device,
                msa,
                'delete_big_ip_vlan',
                msa_device_id,
                partition_id,
                partition_id + '_' + vlan_id
            )
        except:
            if job_cleaning_mode == '1':
                self.output_log_fatal(__name__, traceback.format_exc())
            else:
                raise

    def __get_db_apl(self, job_input):

        node_id = job_input['node_id']

        # Get Endpoint(DB Client)
        db_endpoint = self.get_db_endpoint(self.job_config.REST_URI_APL)

        # Create Instance(DB Client)
        db_list = list.ListClient(self.job_config)

        # List NAL_VNF_MNG(DB Client)
        params = {}
        params['delete_flg'] = 0
        params['node_id'] = node_id
        db_list.set_context(db_endpoint, params)
        db_list.execute()
        apl_list = db_list.get_return_param()

        return apl_list[0]

    def __update_db_apl(self, job_input, act_sby, node_detail_update):

        # Get JOB Input Parameters
        operation_id = job_input['operation_id']
        node_id = job_input['node_id']

        # Get Endpoint(DB Client)
        db_endpoint = self.get_db_endpoint(self.job_config.REST_URI_APL)

        # Create Instance(DB Client)
        db_list = list.ListClient(self.job_config)
        db_update = update.UpdateClient(self.job_config)

        # List NAL_VNF_MNG(DB Client)
        params = {}
        params['delete_flg'] = 0
        params['node_id'] = node_id
        db_list.set_context(db_endpoint, params)
        db_list.execute()
        apl_list = db_list.get_return_param()

        if act_sby == 'act':
            node_detail_dict = json.loads(apl_list[0]['device_detail_master'])
        else:
            node_detail_dict = json.loads(apl_list[0]['device_detail_slave'])
        node_detail_dict.update(node_detail_update)

        # Update NAL_LICENSE_MNG(DB Client)
        keys = [apl_list[0]['ID']]
        params = {}
        params['update_id'] = operation_id
        if act_sby == 'act':
            params['device_detail_master'] = json.dumps(node_detail_dict)
        else:
            params['device_detail_slave'] = json.dumps(node_detail_dict)
        db_update.set_context(db_endpoint, keys, params)
        db_update.execute()

    def __update_db_port(self, job_input, act_sby, port_id, msa_info):

        # Get JOB Input Parameters
        operation_id = job_input['operation_id']
        nal_tenant_id = job_input['nal_tenant_id']

        # Get Endpoint(DB Client)
        db_endpoint = self.get_db_endpoint(self.job_config.REST_URI_PORT)

        # Create Instance(DB Client)
        db_list = list.ListClient(self.job_config)
        db_update = update.UpdateClient(self.job_config)

        # List NAL_VNF_MNG(DB Client)
        params = {}
        params['delete_flg'] = 0
        params['tenant_id'] = nal_tenant_id
        params['port_id'] = port_id
        db_list.set_context(db_endpoint, params)
        db_list.execute()
        port_list = db_list.get_return_param()

        wk = {}
        wk[act_sby] = msa_info
        msa_info_dict = json.loads(port_list[0]['msa_info'])
        msa_info_dict.update(msa_info_dict)

        # Update NAL_LICENSE_MNG(DB Client)
        keys = [port_list[0]['ID']]
        params = {}
        params['update_id'] = operation_id
        params['msa_info'] = json.dumps(msa_info_dict)
        db_update.set_context(db_endpoint, keys, params)
        db_update.execute()
