# -*- coding: utf-8 -*-

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#
import inspect

from job.auto import base
from job.lib.db import list


class Hostname(base.JobAutoBase):

    def hostname_check(self, job_input):

        function_name = inspect.currentframe().f_code.co_name

        # Output Log(Job Input)
        self.output_log_job_params(self.LOG_TYPE_INPUT,
                                         __name__, function_name, job_input)

        # Get JOB Input Parameters
        host_name = job_input['host_name']
        nal_tenant_name = job_input['tenant_name']
        apl_table_rec_id = job_input['apl_table_rec_id']

        # Get Endpoint(DB Client)
        db_endpoint_apl = self.get_db_endpoint(
                                            self.job_config.REST_URI_APL)

        # List NAL_VNF_MNG(DB Client)
        db_list = list.ListClient(self.job_config)
        params = {}
        params['tenant_name'] = nal_tenant_name
        params['node_name'] = host_name
        params['delete_flg'] = 0
        db_list.set_context(db_endpoint_apl, params)
        db_list.execute()
        tenant_list = db_list.get_return_param()

        host_check_flg = 0
        for tenant_data in tenant_list:
            if tenant_data['ID'] != apl_table_rec_id:
                host_check_flg = 1
                break

        if host_check_flg == 1:
            raise SystemError('host_name duplicated:' + host_name)

        job_output = {}

        # Output Log(Job Output)
        self.output_log_job_params(self.LOG_TYPE_OUTPUT,
                                         __name__, function_name, job_output)

        return job_output
