import datetime
import unittest

from job.conf import config
from job.lib.openstack.keystone import tokens
from job.lib.openstack.nova import flavors
from job.lib.openstack.nova import servers
from job.lib.openstack.quantum import networks
from job.lib.openstack.quantum import ports
from job.lib.openstack.quantum import subnets
from pprint import pprint


class TestSelectAPI(unittest.TestCase):
    # Do a test of Select.

    ID = 0

    def setUp(self):

        # Establish a clean test environment.
        super(TestSelectAPI, self).setUp()

        # Insert test data
        self.create_fixtures()

    def tearDown(self):
        """Clear the test environment"""
        super(TestSelectAPI, self).tearDown()
        self.destroy_fixtures()

    def create_fixtures(self):

        pass

    def destroy_fixtures(self):

        pass

    def test_nova(self):

        endpoint = 'http://localhost:8080/api_nal/Stubs/OpenStackClient' \
                                                        + '/index.php?/v2.0'
        #endpoint = 'http://10.58.70.69:5000/v2.0'
        admin_user_name = 'admin'
        admin_password = 'i-portal'
        tenant_id = '9ba7d56906cc4d0cbe055e06971b12a7'
        sv_name = 'sv_ksp'
        nw_name = 'nw_ksp'
        subnet_name = 'subnet_ksp'
        port_name = 'port_ksp'
        cidr = '0.0.0.0/27'

        imageRef = '55f7012b-4c5b-4fb8-90c7-2e1e1205e128'
        flavorRef = '2'

        network_list = [
            {
                'uuid': '6141844163e191152455519bc83d2bda',
                'port': 'b411cd48241a5d2bc11b02cac16e2f91',
            }
        ]

        job_config = config.JobConfig()

        token = tokens.OscTokens(job_config).create_token(
                                admin_user_name, admin_password, endpoint)
        print('create_token')
        pprint(token)

        endpoint_array = tokens.OscTokens(job_config).get_endpoints(
            endpoint, token, admin_user_name, admin_password, '', tenant_id)
        print('get_endpoints')
        pprint(endpoint_array)

        endpoint_array['region_id'] = 'region_unit_test1'

        # Create Network
        nw_name_new = nw_name \
                        + datetime.datetime.today().strftime('%Y%m%d%H%M%S')
        res = networks.OscQuantumNetworks(job_config)\
                                .create_network(endpoint_array, nw_name_new)
        print('create_network')
        pprint(res)

        # Create Subnet
        nw_id_new = res['network']['id']
        subnet_name_new = subnet_name \
                    + datetime.datetime.today().strftime('%Y%m%d%H%M%S')
        res = subnets.OscQuantumSubnets(job_config)\
            .create_subnet(endpoint_array, nw_id_new, cidr, subnet_name_new)
        print('create_subnet')
        pprint(res)

        # Create Port
        subnet_id_new = res['subnet']['id']
        port_name_new = port_name \
                    + datetime.datetime.today().strftime('%Y%m%d%H%M%S')
        res = ports.OscQuantumPorts(job_config)\
                    .create_port(endpoint_array, nw_id_new, port_name_new)
        print('create_port')
        pprint(res)

        # Create Server
        port_id_new = res['port']['id']
        sv_name_new = sv_name \
                    + datetime.datetime.today().strftime('%Y%m%d%H%M%S')
        network_list[0]['uuid'] = nw_id_new
        network_list[0]['port'] = port_id_new
        res = servers.OscServers(job_config).create_server(
            endpoint_array, sv_name_new, imageRef, flavorRef, network_list)
        print('create_server')
        pprint(res)

        # Assertion
        self.assertGreaterEqual(len(res), 1)

        # Get Server
        server_id_new = res['server']['id']
        res = servers.OscServers(job_config)\
                                .get_server(endpoint_array, server_id_new)
        print('get_server')
        pprint(res)

        # Assertion
        self.assertGreaterEqual(len(res), 1)

        # Action Server(Resume)
        actionkey = servers.OscServers(job_config).SERVER_ACTION_RESUME
        res = servers.OscServers(job_config)\
                .action_server(endpoint_array, server_id_new, actionkey)
        print('action_server(resume)')
        pprint(res)

        # Assertion
        self.assertEqual(res, None)

        # Action Server(Reset Network)
        actionkey = servers.OscServers(job_config).SERVER_ACTION_RESETNETWORK
        res = servers.OscServers(job_config)\
                .action_server(endpoint_array, server_id_new, actionkey)
        print('action_server(reset network)')
        pprint(res)

        # Assertion
        self.assertEqual(res, None)

        # Action Server(Suspend)
        actionkey = servers.OscServers(job_config).SERVER_ACTION_SUSPEND
        res = servers.OscServers(job_config)\
                .action_server(endpoint_array, server_id_new, actionkey)
        print('action_server(suspend)')
        pprint(res)

        # Assertion
        self.assertEqual(res, None)

        # Action Server(Reboot)
        actionkey = servers.OscServers(job_config).SERVER_ACTION_REBOOT
        boottype = servers.OscServers(job_config).SERVER_REBOOT_TYPE_SOFT
        res = servers.OscServers(job_config).action_server(
                        endpoint_array, server_id_new, actionkey, boottype)
        print('action_server(reboot)')
        pprint(res)

        # Assertion
        self.assertEqual(res, None)

        # Action Server(Resize)
        actionkey = servers.OscServers(job_config).SERVER_ACTION_RESIZE
        res = servers.OscServers(job_config)\
                .action_server(endpoint_array, server_id_new, None, '2')
        print('action_server(resize)')
        pprint(res)

        # Assertion
        self.assertEqual(res, None)

        # Action Server(Confirm Resize)
        actionkey = servers.OscServers(job_config).SERVER_ACTION_CONFIRMRESIZE
        res = servers.OscServers(job_config)\
                .action_server(endpoint_array, server_id_new, actionkey)
        print('action_server(confirm resize)')
        pprint(res)

        # Assertion
        self.assertEqual(res, None)

        # Action Server(OS Start)
        actionkey = servers.OscServers(job_config).SERVER_ACTION_OS_START
        res = servers.OscServers(job_config)\
                .action_server(endpoint_array, server_id_new, actionkey)
        print('action_server(os start)')
        pprint(res)

        # Assertion
        self.assertEqual(res, None)

        # Action Server(OS Stop)
        actionkey = servers.OscServers(job_config).SERVER_ACTION_OS_STOP
        res = servers.OscServers(job_config)\
                .action_server(endpoint_array, server_id_new, actionkey)
        print('action_server(os stop)')
        pprint(res)

        # Assertion
        self.assertEqual(res, None)

        # Action Server(Get Console)
        actionkey = servers.OscServers(job_config).SERVER_ACTION_GETCONSOLE
        res = servers.OscServers(job_config).action_server(
            endpoint_array, server_id_new, actionkey, None, None, 'xvpvnc')
        print('action_server(get console)')
        pprint(res)

        # Assertion
        self.assertGreaterEqual(len(res), 1)

        # Action Server(Status Pause)
        actionkey = servers.OscServers(job_config).SERVER_STATUS_PAUSE
        res = servers.OscServers(job_config)\
                .action_server(endpoint_array, server_id_new, actionkey)
        print('action_server(status pause)')
        pprint(res)

        # Assertion
        self.assertEqual(res, None)

        # Attach Interface
        res = servers.OscServers(job_config)\
                .attach_interface(endpoint_array, server_id_new, port_id_new)
        print('attach_interface')
        pprint(res)

        # Assertion
        self.assertGreaterEqual(len(res), 1)

        # List Interfaces
        res = servers.OscServers(job_config)\
                .list_interfaces(endpoint_array, server_id_new)
        print('list_interfaces')
        pprint(res)

        # Assertion
        self.assertGreaterEqual(len(res), 1)

        # List Flavors
        res = flavors.OscNovaFlavors(job_config)\
                .list_flavors(endpoint_array)
        print('list_flavors')
        pprint(res)

        # Assertion
        self.assertGreaterEqual(len(res), 1)

        # Detach Interface
        res = servers.OscServers(job_config)\
                .detach_interface(endpoint_array, server_id_new, port_id_new)
        print('detach_interface')
        pprint(res)

        # Assertion
        self.assertEqual(len(res), 0)

        # Delete Port
        res = ports.OscQuantumPorts(job_config)\
                                .delete_port(endpoint_array, port_id_new)
        print('delete_port')
        pprint(res)

        # Delete Subnet
        res = subnets.OscQuantumSubnets(job_config)\
                            .delete_subnet(endpoint_array, subnet_id_new)
        print('delete_subnet')
        pprint(res)

        # Delete Network
        res = networks.OscQuantumNetworks(job_config)\
                                .delete_network(endpoint_array, nw_id_new)
        print('delete_network')
        pprint(res)

        # Delete Server
        res = servers.OscServers(job_config)\
                                .delete_server(endpoint_array, server_id_new)
        print('delete_server')
        pprint(res)

        # Assertion
        self.assertEqual(len(res), 0)

    def test_nova_endpoint_not_found(self):

        endpoint = 'http://localhost:8080/api_nal/Stubs/OpenStackClient' \
                                                        + '/index.php?/v2.0'
        admin_user_name = 'admin'
        admin_password = 'i-portal'
        tenant_id = '9ba7d56906cc4d0cbe055e06971b12a7'
        imageRef = '55f7012b-4c5b-4fb8-90c7-2e1e1205e128'
        flavorRef = '2'

        network_list = [
            {
                'uuid': '6141844163e191152455519bc83d2bda',
                'port': 'b411cd48241a5d2bc11b02cac16e2f91',
            }
        ]

        job_config = config.JobConfig()

        token = tokens.OscTokens(job_config).create_token(
                                admin_user_name, admin_password, endpoint)

        endpoint_array = tokens.OscTokens(job_config).get_endpoints(
            endpoint, token, admin_user_name, admin_password, '', tenant_id)

        endpoint_array['region_id'] = 'regionNotfound'

        # Create Server
        try:
            servers.OscServers(job_config).create_server(endpoint_array,
                            'sv_name_new', imageRef, flavorRef, network_list)

        except SystemError as e:
            if e.args[0] != servers.OscServers.EXCEPT_MSG08:
                raise
