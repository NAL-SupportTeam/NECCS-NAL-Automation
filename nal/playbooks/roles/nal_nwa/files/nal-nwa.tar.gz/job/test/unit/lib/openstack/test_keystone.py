import datetime
# import json
# import inspect
# import os
# import socket
# import struct
# import sys
import unittest

#sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/../../../../')
from job.conf import config
from job.lib.openstack.keystone import roles
from job.lib.openstack.keystone import tenants
from job.lib.openstack.keystone import tokens
from job.lib.openstack.keystone import users
from pprint import pprint


class TestSelectAPI(unittest.TestCase):
    # Do a test of Select.

    ID = 0

    def setUp(self):

        # Establish a clean test environment.
        super(TestSelectAPI, self).setUp()

        # Insert test data
        self.create_fixtures()

    def tearDown(self):
        """Clear the test environment"""
        super(TestSelectAPI, self).tearDown()
        self.destroy_fixtures()

    def create_fixtures(self):

        pass

    def destroy_fixtures(self):

        pass

    def test_keystone(self):

        endpoint = 'http://localhost:8080/api_nal/Stubs/OpenStackClient' \
                                                        + '/index.php?/v2.0'
#         endpoint = 'http://10.58.70.69:5000/v2.0'
        admin_user_name = 'admin'
        admin_password = 'i-portal'
        tenant_name = 'admin'
        tenant_id = '9ba7d56906cc4d0cbe055e06971b12a7'
        user_name = 'test_user'
        user_password = 'user_pass"123'
        role_id = '448b6262a6d34ace9d673c7ac184500c'

        job_config = config.JobConfig()

        # Create Token
        token = tokens.OscTokens(job_config)\
                    .create_token(admin_user_name, admin_password, endpoint)
        print('create_token')
        pprint(token)

        # Assertion
        self.assertGreaterEqual(len(token), 1)

        # Get Endpoints
        endpoint_array = tokens.OscTokens(job_config).get_endpoints(
            endpoint, token, admin_user_name, admin_password, '', tenant_id)
        print('get_endpoints')
        pprint(endpoint_array)

        endpoint_array['region_id'] = 'region_unit_test1'

        # Assertion
        self.assertGreaterEqual(len(endpoint_array), 1)

        # Create Tenant
        tenant_name_new = tenant_name + datetime.datetime.today(
                                                    ).strftime('%Y%m%d%H%M%S')
        res = tenants.OscTenants(job_config)\
                            .create_tenant(endpoint_array, tenant_name_new)
        print('create_tenant')
        pprint(res)

        # Assertion
        self.assertGreaterEqual(len(res), 1)

        # Get Tenant
        tenant_id_new = res['tenant']['id']
        res = tenants.OscTenants(job_config)\
                            .get_tenant(endpoint_array, tenant_id_new)
        print('get_tenant')
        pprint(res)

        # Assertion
        self.assertGreaterEqual(len(res), 1)

        # Update Tenant
        res = tenants.OscTenants(job_config).update_tenant(
                    endpoint_array, tenant_id_new, tenant_name_new + 'upd')
        print('update_tenant')
        pprint(res)

        # Assertion
        self.assertGreaterEqual(len(res), 1)

        # List Tenants
        res = tenants.OscTenants(job_config).list_tenants(endpoint_array)
        print('list_tenants')
        pprint(res)

        # Assertion
        self.assertGreaterEqual(len(res), 1)

        # Create User
        user_name_new = user_name + datetime.datetime.today(
                                                    ).strftime('%Y%m%d%H%M%S')
        res = users.OscUsers(job_config).create_user(
                endpoint_array, user_name_new, user_password, tenant_id_new)
        print('create_user')
        pprint(res)

        # Assertion
        self.assertGreaterEqual(len(res), 1)

        # Get User
        user_id_new = res['user']['id']
        res = users.OscUsers(job_config).get_user(endpoint_array, user_id_new)
        print('get_tenant')
        pprint(res)

        # Assertion
        self.assertGreaterEqual(len(res), 1)

        # Update User
        res = users.OscUsers(job_config).update_user(
                endpoint_array, user_id_new, '', user_name_new + 'upd', '')
        print('update_user')
        pprint(res)

        # Assertion
        self.assertGreaterEqual(len(res), 1)

        # Update User Enabled
        res = users.OscUsers(job_config)\
                .update_user_enabled(endpoint_array, user_id_new, False)
        print('update_user_enabled')
        pprint(res)

        # Assertion
        self.assertGreaterEqual(len(res), 1)

        # Update User Enabled
        res = users.OscUsers(job_config).update_user_password(
                        endpoint_array, user_id_new, user_password + 'upd')
        print('update_user_password')
        pprint(res)

        # Assertion
        self.assertGreaterEqual(len(res), 1)

        # List Users
        res = users.OscUsers(job_config).list_users(endpoint_array)
        print('list_users')
        pprint(res)

        # Assertion
        self.assertGreaterEqual(len(res), 1)

        # List Users(tenant)
        res = users.OscUsers(job_config)\
                                .list_users(endpoint_array, tenant_id_new)
        print('list_users(tenant)')
        pprint(res)

        # Add Role To User
        res = roles.OscRoles(job_config).add_role_to_user(
                        endpoint_array, user_id_new, tenant_id_new, role_id)
        print('add_role_to_user')
        pprint(res)

        # Assertion
        self.assertGreaterEqual(len(res), 1)

        # List Role
        res = roles.OscRoles(job_config).list_roles(endpoint_array)
        print('list_roles')
        pprint(res)

        # Assertion
        self.assertGreaterEqual(len(res), 1)

        # List Role For User
        res = roles.OscRoles(job_config)\
            .list_roles_for_user(endpoint_array, user_id_new, tenant_id_new)
        print('list_roles_for_user')
        pprint(res)

        # Assertion
        self.assertGreaterEqual(len(res), 1)

        # Remove Role From User
        res = roles.OscRoles(job_config).remove_role_from_user(
                        endpoint_array, user_id_new, tenant_id_new, role_id)
        print('remove_role_from_user')
        pprint(res)

        # Assertion
        self.assertEqual(len(res), 0)

        # Delete User
        res = users.OscUsers(job_config)\
                                .delete_user(endpoint_array, user_id_new)
        print('delete_user')
        pprint(res)

        # Assertion
        self.assertEqual(len(res), 0)

        # Delete Tenant
        res = tenants.OscTenants(job_config)\
                                .delete_tenant(endpoint_array, tenant_id_new)
        print('delete_tenant')
        pprint(res)

        # Assertion
        self.assertEqual(len(res), 0)

    def test_keystone_endpoint_not_found(self):

        endpoint = 'http://localhost:8080/api_nal/Stubs/OpenStackClient' \
                                                        + '/index.php?/v2.0'
        admin_user_name = 'admin'
        admin_password = 'i-portal'
        tenant_id = '9ba7d56906cc4d0cbe055e06971b12a7'

        job_config = config.JobConfig()

        # Create Token
        token = tokens.OscTokens(job_config)\
                    .create_token(admin_user_name, admin_password, endpoint)

        # Assertion
        self.assertGreaterEqual(len(token), 1)

        # Get Endpoints
        endpoint_array = tokens.OscTokens(job_config).get_endpoints(
            endpoint, token, admin_user_name, admin_password, '', tenant_id)

        endpoint_array['region_id'] = 'region_unit_test1'

        endpoint_array['region_id'] = 'regionNotfound'

        # Create Server
        try:
            tenants.OscTenants(job_config)\
                            .create_tenant(endpoint_array, 'tenant_name_new')

        except SystemError as e:
            if e.args[0] != tenants.OscTenants.EXCEPT_MSG08:
                raise
