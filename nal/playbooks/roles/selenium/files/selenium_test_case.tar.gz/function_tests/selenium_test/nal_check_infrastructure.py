#  Licensed under the Apache License, Version 2.0 (the "License"); you may
#  not use this file except in compliance with the License. You may obtain
#  a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#  WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#  License for the specific language governing permissions and limitations
#  under the License.
#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016

from ConfigParser import SafeConfigParser
import datetime
import os
import sys

from assemble import nal as nal_list
import base
from conf import config
from conf import test_scenario

from selenium import webdriver

SET_BASE_URL = getattr(config, "SET_BASE_URL")
SET_WIDTH = getattr(config, "SET_WIDTH", 1280)
SET_HEIGHT = getattr(config, "SET_HEIGHT", 1024)
SET_TIMEOUT = getattr(config, "SET_TIMEOUT", 5)


class SeleniumNalTest(base.SeleniumBase):

    def __init__(self, driver, evidence):
        super(SeleniumNalTest, self).__init__(driver, evidence)
        self.driver = driver
        self.evidence = evidence

    def main(self):

        test_scenario_name = sys.argv[1]
        test_flow = getattr(test_scenario, test_scenario_name)
        test_instance = nal_list.NalTestMethod(self.driver, self.evidence)

        self.output_log_start(test_scenario_name)
        for test_info in test_flow:
            try:
                test_method = test_info["method"]
                input_params = test_info.get("input_params", None)
                test_method_attr = getattr(test_instance, test_method)
                if input_params:
                    test_method_attr(input_params)
                else:
                    test_method_attr()
            except Exception as e:
                self.output_log_result(test_method, "NG")
                self.output_log_end()
                raise e
            self.output_log_result(test_method, "OK")

        self.output_log_end()


if __name__ == "__main__":

    ### File check
    profile_path = "/root/.mozilla/firefox/"
    if not os.path.exists(profile_path):
        raise Exception("Profile does not exist")

    for folder_name in os.listdir(profile_path):
        if os.path.isdir(profile_path + folder_name):
            if folder_name.count('.default'):
                profile = profile_path + folder_name
                break
    else:
        raise Exception("Profile does not exist")

    selenium_driver = webdriver.Firefox(firefox_profile=profile)
    selenium_driver.implicitly_wait(30)
    selenium_driver.set_window_size(SET_WIDTH, SET_HEIGHT)

    now_time = datetime.datetime.today().strftime("%Y%m%d%H%M%S")
    evidence = {"evidence_name": str(now_time)}
    try:
        selenium_test = SeleniumNalTest(selenium_driver, evidence)
        selenium_test.main()
    except Exception as e:
        print(e)
    finally:
        selenium_driver.quit()
