# Base URL. Environment for testing.
# As for the URL, the last slash is unnecessary.
SET_BASE_URL = "http://10.58.70.107"
# Login user
USER_NAME = "admin"
USER_PASSWORD = "admin"
PROJECT_NAME = "nal_auto_test"
# Version set
SET_NAL_VERSION = "2"

# Display language
SET_LANGUAGE = "en"
# Width of the window.
SET_WIDTH = 1280
# Height of the window.
SET_HEIGHT = 960
# Timeout.
SET_TIMEOUT = 3
# Capture of location.
SET_EVIDENCE = "evidence/"
# Timeout setting of Create.
SET_CREATE_WAITTIME = 30
SET_CREATE_RETRYCOUNT = 60
# Timeout setting of Update.
SET_UPDATE_WAITTIME = 30
SET_UPDATE_RETRYCOUNT = 20
# Timeout setting of Delete.
SET_DELETE_WAITTIME = 30
SET_DELETE_RETRYCOUNT = 20

# Setting for environment construction
ZABBIX_VIP_IP = ""
ZABBIX_01_IP = ""
ZABBIX_02_IP = ""
DNS_PRIMARY_IP = ""
DNS_SECONDARY_IP = ""
NTP_PRAMARY_IP = ""
NTP_SECONDARY_IP = ""
