#  Licensed under the Apache License, Version 2.0 (the "License"); you may
#  not use this file except in compliance with the License. You may obtain
#  a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#  WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#  License for the specific language governing permissions and limitations
#  under the License.
#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016

import base
from conf import config

from selenium import webdriver
from selenium.webdriver.support.ui import Select

SET_BASE_URL = getattr(config, 'SET_BASE_URL')
SET_LANGUAGE = getattr(config, "SET_LANGUAGE", "en")
USER_NAME = getattr(config, 'USER_NAME')
USER_PASSWORD = getattr(config, 'USER_PASSWORD')
PROJECT_NAME = getattr(config, 'PROJECT_NAME')


class SettingOperations(base.SeleniumBase):
    def __init__(self, driver, evidence):
        super(SettingOperations, self).__init__(driver, evidence)
        self.driver = driver
        self.evidence = evidence

    def sign_in(self):
        driver = self.driver
        driver.get(SET_BASE_URL + "/dashboard/auth/login/?next=/dashboard/")
        self.sleep_time()
        driver.find_element_by_id("id_username").clear()
        driver.find_element_by_id("id_username").send_keys(USER_NAME)
        driver.find_element_by_id("id_password").clear()
        driver.find_element_by_id("id_password").send_keys(USER_PASSWORD)
        driver.find_element_by_id("loginBtn").click()
        self.sleep_time()

    def change_project(self):
        driver = self.driver
        driver.find_element_by_xpath(
            "//a[contains(@href, '#')]").click()
        self.sleep_time()
        driver.find_element_by_link_text(PROJECT_NAME).click()
        self.sleep_time()

    def change_setting(self):
        driver = self.driver
        driver.get(SET_BASE_URL + "/dashboard/settings/")
        self.sleep_time()
        Select(driver.find_element_by_id(
            'id_language')).select_by_value(SET_LANGUAGE)
        driver.find_element_by_css_selector("input[type=submit]").click()
        self.sleep_time()

    def sign_out(self):
        driver = self.driver
        driver.find_element_by_xpath(
            "//div[@id='navbar-collapse']/ul[2]/li/a/span[2]").click()
        self.sleep_time()
        driver.find_element_by_link_text("Sign Out").click()
        self.sleep_time()
