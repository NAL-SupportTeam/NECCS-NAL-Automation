from conf import config

ZABBIX_VIP_IP = getattr(config, "ZABBIX_VIP_IP")
ZABBIX_01_IP = getattr(config, "ZABBIX_01_IP")
ZABBIX_02_IP = getattr(config, "ZABBIX_02_IP")
DNS_PRIMARY_IP = getattr(config, "DNS_PRIMARY_IP")
DNS_SECONDARY_IP = getattr(config, "DNS_SECONDARY_IP")
NTP_PRAMARY_IP = getattr(config, "NTP_PRAMARY_IP")
NTP_SECONDARY_IP = getattr(config, "NTP_SECONDARY_IP")

# ---------------------------------------------------------------
# InterSecVM SG for Ext
# ---------------------------------------------------------------
node_intersecvm_sg_for_ext_create = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_create",
        "input_params": {
            "apl_type": "1",
            "type": "1",
            "device_type": "1",
            "subnet_info": "nal_check_infra_net: 10.58.70.0/24 (nal_check_infra_sub01)",
            "host_name": "test_node_intersecvm_sg_for_ext",
            "webclient_ip": "10.10.10.10",
            "zabbix_vip_ip": ZABBIX_VIP_IP,
            "zabbix_01_ip": ZABBIX_01_IP,
            "zabbix_02_ip": ZABBIX_02_IP,
            "ntp_server_primary": NTP_PRAMARY_IP
        }
    },
    {
        "method": "node_list",
    },
    {
        "method": "node_detail",
        "input_params": {
            "host_name": "test_node_intersecvm_sg_for_ext"
        }
    },
    {
        "method": "node_list_admin",
    },
    {
        "method": "node_detail_admin",
        "input_params": {
            "host_name": "test_node_intersecvm_sg_for_ext"
        }
    },
    {
        "method": "sign_out"
    }
]

node_intersecvm_sg_for_ext_update = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_add_interface",
        "input_params": {
            "host_name": "test_node_intersecvm_sg_for_ext",
            "subnet_info": "nal_check_infra_net: 10.58.71.0/24 (nal_check_infra_sub02)"
        }
    },
    {
        "method": "node_delete_interface",
        "input_params": {
            "host_name": "test_node_intersecvm_sg_for_ext"
        }
    },
    {
        "method": "sign_out"
    }
]

node_intersecvm_sg_for_ext_delete = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_delete",
        "input_params": {
            "host_name": "test_node_intersecvm_sg_for_ext"
        }
    },
    {
        "method": "sign_out"
    }
]

# ---------------------------------------------------------------
# FortiGateVM
# ---------------------------------------------------------------
node_fortigatevm_create = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_create",
        "input_params": {
            "apl_type": "1",
            "type": "1",
            "device_type": "2",
            "subnet_info": "nal_check_infra_net: 10.58.70.0/24 (nal_check_infra_sub01)",
            "host_name": "test_node_fortigatevm",
            "admin_id": "nalid",
            "admin_pw": "nalpw",
            "dns_server_primary": DNS_PRIMARY_IP,
            "dns_server_secondary": DNS_SECONDARY_IP,
            "ntp_server_primary": NTP_PRAMARY_IP,
            "ntp_server_secondary": NTP_SECONDARY_IP
        }
    },
    {
        "method": "node_list",
    },
    {
        "method": "node_detail",
        "input_params": {
            "host_name": "test_node_fortigatevm"
        }
    },
    {
        "method": "node_list_admin",
    },
    {
        "method": "node_detail_admin",
        "input_params": {
            "host_name": "test_node_fortigatevm"
        }
    },
    {
        "method": "sign_out"
    }
]

node_fortigatevm_update = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_add_interface",
        "input_params": {
            "host_name": "test_node_fortigatevm",
            "subnet_info": "nal_check_infra_net: 10.58.71.0/24 (nal_check_infra_sub02)"
        }
    },
    {
        "method": "sign_out"
    }
]

node_fortigatevm_delete = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_delete",
        "input_params": {
            "host_name": "test_node_fortigatevm"
        }
    },
    {
        "method": "sign_out"
    }
]

# ---------------------------------------------------------------
# PaloAltoVM
# ---------------------------------------------------------------
node_paloaltovm_create = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_create",
        "input_params": {
            "apl_type": "1",
            "type": "1",
            "device_type": "3",
            "subnet_info": "nal_check_infra_net: 10.58.70.0/24 (nal_check_infra_sub01)",
            "host_name": "test_node_paloaltovm",
            "admin_id": "nalid",
            "admin_pw": "nalpw",
            "pavm_zone_name": "zone1",
            "dns_server_primary": DNS_PRIMARY_IP,
            "dns_server_secondary": DNS_SECONDARY_IP,
            "ntp_server_primary": NTP_PRAMARY_IP,
            "ntp_server_secondary": NTP_SECONDARY_IP
        }
    },
    {
        "method": "node_list",
    },
    {
        "method": "node_detail",
        "input_params": {
            "host_name": "test_node_paloaltovm"
        }
    },
    {
        "method": "node_list_admin",
    },
    {
        "method": "node_detail_admin",
        "input_params": {
            "host_name": "test_node_paloaltovm"
        }
    },
    {
        "method": "sign_out"
    }
]

node_paloaltovm_update = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_assign_license",
        "input_params": {
            "host_name": "test_node_paloaltovm"
        }
    },
    {
        "method": "node_add_interface",
        "input_params": {
            "host_name": "test_node_paloaltovm",
            "subnet_info": "nal_check_infra_net: 10.58.71.0/24 (nal_check_infra_sub02)",
            "pavm_zone_name": "zone1"
        }
    },
    {
        "method": "node_delete",
        "input_params": {
            "host_name": "test_node_paloaltovm"
        }
    },
    {
        "method": "sign_out"
    }
]

node_paloaltovm_delete = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_delete",
        "input_params": {
            "host_name": "test_node_paloaltovm"
        }
    },
    {
        "method": "sign_out"
    }
]

# ---------------------------------------------------------------
# InterSecVM SG for Pub
# ---------------------------------------------------------------
node_intersecvm_sg_for_pub_create = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_create",
        "input_params": {
            "apl_type": "1",
            "type": "1",
            "device_type": "4",
            "subnet_info": "nal_check_infra_net: 10.58.70.0/24 (nal_check_infra_sub01)",
            "host_name": "test_node_intersecvm_sg_for_pub",
            "webclient_ip": "10.10.10.10",
            "zabbix_vip_ip": ZABBIX_VIP_IP,
            "zabbix_01_ip": ZABBIX_01_IP,
            "zabbix_02_ip": ZABBIX_02_IP,
            "ntp_server_primary": NTP_PRAMARY_IP
        }
    },
    {
        "method": "node_list",
    },
    {
        "method": "node_detail",
        "input_params": {
            "host_name": "test_node_intersecvm_sg_for_pub"
        }
    },
    {
        "method": "node_list_admin",
    },
    {
        "method": "node_detail_admin",
        "input_params": {
            "host_name": "test_node_intersecvm_sg_for_pub"
        }
    },
    {
        "method": "sign_out"
    }
]

node_intersecvm_sg_for_pub_update = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_add_interface",
        "input_params": {
            "host_name": "test_node_intersecvm_sg_for_pub",
            "subnet_info": "nal_check_infra_net: 10.58.71.0/24 (nal_check_infra_sub02)"
        }
    },
    {
        "method": "node_delete_interface",
        "input_params": {
            "host_name": "test_node_intersecvm_sg_for_pub"
        }
    },
    {
        "method": "sign_out"
    }
]

node_intersecvm_sg_for_pub_delete = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_delete",
        "input_params": {
            "host_name": "test_node_intersecvm_sg_for_pub"
        }
    },
    {
        "method": "sign_out"
    }
]

# ---------------------------------------------------------------
# FortiGateVM 5.4.1
# ---------------------------------------------------------------
node_fortigatevm_541_create = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_create",
        "input_params": {
            "apl_type": "1",
            "type": "1",
            "device_type": "5",
            "subnet_info": "nal_check_infra_net: 10.58.70.0/24 (nal_check_infra_sub01)",
            "host_name": "test_node_fortigatevm_541",
            "admin_id": "nalid",
            "admin_pw": "nalpw",
            "dns_server_primary": DNS_PRIMARY_IP,
            "dns_server_secondary": DNS_SECONDARY_IP,
            "ntp_server_primary": NTP_PRAMARY_IP,
            "ntp_server_secondary": NTP_SECONDARY_IP
        }
    },
    {
        "method": "node_list",
    },
    {
        "method": "node_detail",
        "input_params": {
            "host_name": "test_node_fortigatevm_541"
        }
    },
    {
        "method": "node_list_admin",
    },
    {
        "method": "node_detail_admin",
        "input_params": {
            "host_name": "test_node_fortigatevm_541"
        }
    },
    {
        "method": "sign_out"
    }
]

node_fortigatevm_541_update = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_add_interface",
        "input_params": {
            "host_name": "test_node_fortigatevm_541",
            "subnet_info": "nal_check_infra_net: 10.58.71.0/24 (nal_check_infra_sub02)"
        }
    },
    {
        "method": "sign_out"
    }
]

node_fortigatevm_541_delete = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_delete",
        "input_params": {
            "host_name": "test_node_fortigatevm_541"
        }
    },
    {
        "method": "sign_out"
    }
]

# ---------------------------------------------------------------
# InterSecVM LB
# ---------------------------------------------------------------
node_intersecvm_lb_create = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_create",
        "input_params": {
            "apl_type": "1",
            "type": "2",
            "device_type": "1",
            "subnet_info": "nal_check_infra_net: 10.58.70.0/24 (nal_check_infra_sub01)",
            "host_name": "test_node_intersecvm_lb",
            "fw_ip_address": "192.168.40.252",
            "zabbix_vip_ip": ZABBIX_VIP_IP,
            "zabbix_01_ip": ZABBIX_01_IP,
            "zabbix_02_ip": ZABBIX_02_IP,
            "ntp_server_primary": NTP_PRAMARY_IP
        }
    },
    {
        "method": "node_list",
    },
    {
        "method": "node_detail",
        "input_params": {
            "host_name": "test_node_intersecvm_lb"
        }
    },
    {
        "method": "node_list_admin",
    },
    {
        "method": "node_detail_admin",
        "input_params": {
            "host_name": "test_node_intersecvm_lb"
        }
    },
    {
        "method": "sign_out"
    }
]

node_intersecvm_lb_delete = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_delete",
        "input_params": {
            "host_name": "test_node_intersecvm_lb"
        }
    },
    {
        "method": "sign_out"
    }
]

# ---------------------------------------------------------------
# BIG-IP VE
# ---------------------------------------------------------------
node_bigip_ve_create = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_create",
        "input_params": {
            "apl_type": "1",
            "type": "2",
            "device_type": "2",
            "subnet_info": "nal_check_infra_net: 10.58.70.0/24 (nal_check_infra_sub01)",
            "host_name": "testNodeBigipVe",
            "admin_id": "nalid",
            "admin_pw": "nalpw",
            "fw_ip_address": "192.168.40.252",
            "domain_name": "domain01",
            "self_ip_name": "self01",
            "timezone": "Asia/Tokyo",
            "dns_server_primary": DNS_PRIMARY_IP,
            "dns_server_secondary": DNS_SECONDARY_IP,
            "ntp_server_primary": NTP_PRAMARY_IP,
            "ntp_server_secondary": NTP_SECONDARY_IP
        }
    },
    {
        "method": "node_list",
    },
    {
        "method": "node_detail",
        "input_params": {
            "host_name": "testNodeBigipVe"
        }
    },
    {
        "method": "node_list_admin",
    },
    {
        "method": "node_detail_admin",
        "input_params": {
            "host_name": "testNodeBigipVe"
        }
    },
    {
        "method": "sign_out"
    }
]

node_bigip_ve_delete = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_delete",
        "input_params": {
            "host_name": "testNodeBigipVe"
        }
    },
    {
        "method": "sign_out"
    }
]

# ---------------------------------------------------------------
# vThunder(4.0.1)
# ---------------------------------------------------------------
node_vthunder_create = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_create",
        "input_params": {
            "apl_type": "1",
            "type": "2",
            "device_type": "3",
            "subnet_info": "nal_check_infra_net: 10.58.70.0/24 (nal_check_infra_sub01)",
            "host_name": "testNodeVthunder401",
            "admin_id": "nalid",
            "admin_pw": "nalpw",
            "fw_ip_address": "192.168.40.252",
            "dns_server_primary": DNS_PRIMARY_IP,
            "dns_server_secondary": DNS_SECONDARY_IP,
            "ntp_server_primary": NTP_PRAMARY_IP,
            "ntp_server_secondary": NTP_SECONDARY_IP
        }
    },
    {
        "method": "node_list",
    },
    {
        "method": "node_detail",
        "input_params": {
            "host_name": "testNodeVthunder401"
        }
    },
    {
        "method": "node_list_admin",
    },
    {
        "method": "node_detail_admin",
        "input_params": {
            "host_name": "testNodeVthunder401"
        }
    },
    {
        "method": "sign_out"
    }
]

node_vthunder_update = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_assign_license",
        "input_params": {
            "host_name": "testNodeVthunder401"
        }
    },
    {
        "method": "sign_out"
    }
]

node_vthunder_delete = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_delete",
        "input_params": {
            "host_name": "testNodeVthunder401"
        }
    },
    {
        "method": "sign_out"
    }
]

# ---------------------------------------------------------------
# vThunder(4.1.1)
# ---------------------------------------------------------------
node_vthunder_411_create = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_create",
        "input_params": {
            "apl_type": "1",
            "type": "2",
            "device_type": "4",
            "subnet_info": "nal_check_infra_net: 10.58.70.0/24 (nal_check_infra_sub01)",
            "host_name": "testNodeVthunder411",
            "admin_id": "nalid",
            "admin_pw": "nalpw",
            "fw_ip_address": "192.168.40.252",
            "dns_server_primary": DNS_PRIMARY_IP,
            "dns_server_secondary": DNS_SECONDARY_IP,
            "ntp_server_primary": NTP_PRAMARY_IP,
            "ntp_server_secondary": NTP_SECONDARY_IP
        }
    },
    {
        "method": "node_list",
    },
    {
        "method": "node_detail",
        "input_params": {
            "host_name": "testNodeVthunder411"
        }
    },
    {
        "method": "node_list_admin",
    },
    {
        "method": "node_detail_admin",
        "input_params": {
            "host_name": "testNodeVthunder411"
        }
    },
    {
        "method": "sign_out"
    }
]

node_vthunder_411_update = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_assign_license",
        "input_params": {
            "host_name": "testNodeVthunder411"
        }
    },
    {
        "method": "sign_out"
    }
]

node_vthunder_411_delete = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "node_delete",
        "input_params": {
            "host_name": "testNodeVthunder411"
        }
    },
    {
        "method": "sign_out"
    }
]

# ---------------------------------------------------------------
# CSR1000v
# ---------------------------------------------------------------
service_cisco_l2_create = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "service_create",
        "input_params": {
            "service_name": "test_service_cisco_l2",
            "service_type": "2",
            "subnet_info": "nal_check_infra_net: 10.58.70.0/24 (nal_check_infra_sub01)",
            "bandwidth": "10MB",
            "dns_server_ip_address": "10.58.70.11",
            "ntp_server_ip_address": "10.58.70.12",
            "snmp_server_ip_address": "10.58.70.13",
            "syslog_server_ip_address": "10.58.70.14"
        }
    },
    {
        "method": "service_list"
    },
    {
        "method": "service_detail",
        "input_params": {
            "service_name": "test_service_cisco_l2"
        }
    },
    {
        "method": "service_list_admin"
    },
    {
        "method": "service_detail_admin",
        "input_params": {
            "service_name": "test_service_cisco_l2"
        }
    },
    {
        "method": "sign_out"
    }
]

service_cisco_l2_update = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "service_add_interface",
        "input_params": {
            "service_name": "test_service_cisco_l2",
            "subnet_info": "nal_check_infra_net: 10.58.71.0/24 (nal_check_infra_sub02)",
        }
    },
    {
        "method": "service_bandwidth",
        "input_params": {
            "service_name": "test_service_cisco_l2",
            "bandwidth": "50MB",
        }
    },
    {
        "method": "service_setting",
        "input_params": {
            "service_name": "test_service_cisco_l2",
            "dns_server_ip_address": "10.58.70.21",
            "ntp_server_ip_address": "10.58.70.22",
            "ntp_server_interface": "nal_check_infra_net: 10.58.70.0/24 (nal_check_infra_sub01)",
            "snmp_server_ip_address": "10.58.70.23",
            "snmp_server_interface": "nal_check_infra_net: 10.58.70.0/24 (nal_check_infra_sub01)",
            "snmp_server_delete_flg": "",
            "syslog_server_ip_address": "10.58.70.24",
            "syslog_server_interface": "nal_check_infra_net: 10.58.70.0/24 (nal_check_infra_sub01)",
            "syslog_server_delete_flg": ""
        }
    },
    {
        "method": "sign_out"
    }
]

service_cisco_l2_delete = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "service_delete",
        "input_params": {
            "service_name": "test_service_cisco_l2",
        }
    },
    {
        "method": "sign_out"
    }
]

# ---------------------------------------------------------------
# CSR1000v (Encrypted)
# ---------------------------------------------------------------
service_cisco_l3_encrypted_create = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "service_create",
        "input_params": {
            "service_name": "test_service_cisco_l3_encrypted",
            "service_type": "3",
            "subnet_info": "nal_check_infra_net: 10.58.70.0/24 (nal_check_infra_sub01)",
            "bandwidth": "10MB",
            "dns_server_ip_address": "10.58.70.11",
            "ntp_server_ip_address": "10.58.70.12",
            "snmp_server_ip_address": "10.58.70.13",
            "syslog_server_ip_address": "10.58.70.14"
        }
    },
    {
        "method": "service_list"
    },
    {
        "method": "service_detail",
        "input_params": {
            "service_name": "test_service_cisco_l3_encrypted"
        }
    },
    {
        "method": "service_list_admin"
    },
    {
        "method": "service_detail_admin",
        "input_params": {
            "service_name": "test_service_cisco_l3_encrypted"
        }
    },
    {
        "method": "sign_out"
    }
]

service_cisco_l3_encrypted_update = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "service_add_interface",
        "input_params": {
            "service_name": "test_service_cisco_l3_encrypted",
            "subnet_info": "nal_check_infra_net: 10.58.71.0/24 (nal_check_infra_sub02)",
        }
    },
    {
        "method": "service_bandwidth",
        "input_params": {
            "service_name": "test_service_cisco_l3_encrypted",
            "bandwidth": "50MB",
        }
    },
    {
        "method": "service_setting",
        "input_params": {
            "service_name": "test_service_cisco_l3_encrypted",
            "dns_server_ip_address": "10.58.70.21",
            "ntp_server_ip_address": "10.58.70.22",
            "ntp_server_interface": "nal_check_infra_net: 10.58.70.0/24 (nal_check_infra_sub01)",
            "snmp_server_ip_address": "10.58.70.23",
            "snmp_server_interface": "nal_check_infra_net: 10.58.70.0/24 (nal_check_infra_sub01)",
            "snmp_server_delete_flg": "",
            "syslog_server_ip_address": "10.58.70.24",
            "syslog_server_interface": "nal_check_infra_net: 10.58.70.0/24 (nal_check_infra_sub01)",
            "syslog_server_delete_flg": ""
        }
    },
    {
        "method": "sign_out"
    }
]

service_cisco_l3_encrypted_delete = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "service_delete",
        "input_params": {
            "service_name": "test_service_cisco_l3_encrypted",
        }
    },
    {
        "method": "sign_out"
    }
]

# ---------------------------------------------------------------
# CSR1000v (Unencrypted)
# ---------------------------------------------------------------
service_cisco_l3_plain_create = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "service_create",
        "input_params": {
            "service_name": "test_service_cisco_l3_plain",
            "service_type": "4",
            "subnet_info": "nal_check_infra_net: 10.58.70.0/24 (nal_check_infra_sub01)",
            "bandwidth": "10MB",
            "dns_server_ip_address": "10.58.70.11",
            "ntp_server_ip_address": "10.58.70.12",
            "snmp_server_ip_address": "10.58.70.13",
            "syslog_server_ip_address": "10.58.70.14"
        }
    },
    {
        "method": "service_list"
    },
    {
        "method": "service_detail",
        "input_params": {
            "service_name": "test_service_cisco_l3_plain"
        }
    },
    {
        "method": "service_list_admin"
    },
    {
        "method": "service_detail_admin",
        "input_params": {
            "service_name": "test_service_cisco_l3_plain"
        }
    },
    {
        "method": "sign_out"
    }
]

service_cisco_l3_plain_update = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "service_add_interface",
        "input_params": {
            "service_name": "test_service_cisco_l3_plain",
            "subnet_info": "nal_check_infra_net: 10.58.71.0/24 (nal_check_infra_sub02)",
        }
    },
    {
        "method": "service_bandwidth",
        "input_params": {
            "service_name": "test_service_cisco_l3_plain",
            "bandwidth": "50MB",
        }
    },
    {
        "method": "service_setting",
        "input_params": {
            "service_name": "test_service_cisco_l3_plain",
            "dns_server_ip_address": "10.58.70.21",
            "ntp_server_ip_address": "10.58.70.22",
            "ntp_server_interface": "nal_check_infra_net: 10.58.70.0/24 (nal_check_infra_sub01)",
            "snmp_server_ip_address": "10.58.70.23",
            "snmp_server_interface": "nal_check_infra_net: 10.58.70.0/24 (nal_check_infra_sub01)",
            "snmp_server_delete_flg": "",
            "syslog_server_ip_address": "10.58.70.24",
            "syslog_server_interface": "nal_check_infra_net: 10.58.70.0/24 (nal_check_infra_sub01)",
            "syslog_server_delete_flg": ""
        }
    },
    {
        "method": "sign_out"
    }
]

service_cisco_l3_plain_delete = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "service_delete",
        "input_params": {
            "service_name": "test_service_cisco_l3_plain",
        }
    },
    {
        "method": "sign_out"
    }
]

# ---------------------------------------------------------------
# Global IP
# ---------------------------------------------------------------
resource_globalip_create = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "resource_create",
        "input_params": {
            "resource_name": "Global IP"
        }
    },
    {
        "method": "resource_list",
    },
    {
        "method": "resource_detail",
        "input_params": {
            "resource_name": "Global IP"
        }
    },
    {
        "method": "resource_list_admin"
    },
    {
        "method": "resource_detail_admin",
        "input_params": {
            "resource_name": "Global IP"
        }
    },
    {
        "method": "sign_out"
    }
]

resource_globalip_update = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "resource_update",
        "input_params": {
            "resource_name": "Global IP"
        }
    },
    {
        "method": "sign_out"
    }
]

resource_globalip_delete = [
    {
        "method": "sign_in",
    },
    {
        "method": "change_setting",
    },
    {
        "method": "change_project",
    },
    {
        "method": "resource_delete",
        "input_params": {
            "resource_name": "Global IP"
        }
    },
    {
        "method": "sign_out"
    }
]
