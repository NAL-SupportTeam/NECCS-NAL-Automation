#!/bin/sh

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#

#
#      Creation of Msa
#
. ${NALPATH}/common/NAL_C_Common.sh

#Creation of Msa
`pyfunc virtual_rt_msa_setup`
status=$?
if [ $status != 0 ] ; then
   exit $status
fi

#Creation of router
if [ ${NAL_DEVICETYPE} = ${DEVTYPE_DCCON_FIREFLY} ] ; then
    `pyfunc virtual_rt_device_setup_create_firefly`

elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_DCCON_CSR1000V} ] ; then
    `pyfunc virtual_rt_device_setup_create_csr1000v`
    status=$?
    if [ $status != 0 ] ; then
      exit $status
    fi
    `pyfunc virtual_rt_device_setup_create_csr1000v_extra`

elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_DCCON_CSR1000V_TUNNEL} -o ${NAL_DEVICETYPE} = ${DEVTYPE_DCCON_CSR1000V_TUNNEL_NO_ENCRYPTION} ] ; then
    `pyfunc virtual_rt_device_setup_create_csr1000v_for_tunnel`
    status=$?
    if [ $status != 0 ] ; then
      exit $status
    fi
    `pyfunc virtual_rt_device_setup_create_csr1000v_extra`
fi
exit $?