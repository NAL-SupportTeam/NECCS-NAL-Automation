#!/bin/sh

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#

#
#      Creation of Msa
#
. ${NALPATH}/common/NAL_C_Common.sh
#Set up of router
status=0
if [ ${NAL_DEVICETYPE} = ${DEVTYPE_DCCON_FIREFLY} ] ; then
    `pyfunc virtual_rt_device_setup_update_firefly`
    status=$?
    if [ $status != 0 ] ; then
        exit $status
    fi

    `pyfunc virtual_rt_dc_connect_update_firefly`
    status=$?

elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_DCCON_CSR1000V} ] ; then
    `pyfunc virtual_rt_device_setup_update_csr1000v`
    status=$?
    if [ $status != 0 ] ; then
        exit $status
    fi

    `pyfunc virtual_rt_dc_connect_update_csr1000v`
    status=$?

elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_DCCON_CSR1000V_TUNNEL} -o ${NAL_DEVICETYPE} = ${DEVTYPE_DCCON_CSR1000V_TUNNEL_NO_ENCRYPTION} ] ; then
    `pyfunc virtual_rt_device_setup_update_csr1000v_for_tunnel`
    status=$?
    if [ $status != 0 ] ; then
        exit $status
    fi

    `pyfunc virtual_rt_dc_connect_update_csr1000v_for_tunnel`
    status=$?
fi
exit $status