#!/bin/sh

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#

#
#      Port additional
#
. ${NALPATH}/common/NAL_C_Common.sh

status=0
if [ ${NAL_JOBNAME} = ${JOB_NAME_CREATE_VPORT} ] ; then
    ###Virtual FW Port Additional###

    #Creation of the virtual LAN & port of tenant
    `pyfunc virtual_fw_tenant_vlan_port_create`
    status=$?

elif [ ${NAL_JOBNAME} = ${JOB_NAME_CREATE_PPORT} ] ; then
    ###Physical FW Port Additional###

    #Creation of the virtual LAN & port of tenant
    `pyfunc physical_fw_tenant_vlan_port_create`
    status=$?

fi
exit $status
