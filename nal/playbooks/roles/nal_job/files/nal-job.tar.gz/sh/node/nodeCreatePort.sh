#!/bin/sh

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#

#
#      Creation of the port
#
. ${NALPATH}/common/NAL_C_Common.sh

#Creation of the MSA port
status=0
if [ ${NAL_JOBNAME} = ${JOB_NAME_CREATE_VFW} -o ${NAL_JOBNAME} = ${JOB_NAME_CREATE_VLB}  ] ; then
    ###VNF creation###
    `pyfunc virtual_msa_port_create`
    status=$?
    if [ $status != 0 ] ; then
        exit $status
    fi
fi

status=0
if [ ${NAL_JOBNAME} = ${JOB_NAME_CREATE_VFW} ] ; then
    ###Virtual FW creation###

    #if that is not InterSec(with Internet), create Pub port.
    if [ ${NAL_DEVICETYPE} != ${DEVTYPE_VFW_INTERSEC_SG_EXT} ] ; then
        `pyfunc virtual_pub_port_create`
        status=$?
        if [ $status != 0 ] ; then
           exit $status
        fi
    fi

    #if that is not InterSec(without Internet), create Ext port.
    if [ ${NAL_DEVICETYPE} != ${DEVTYPE_VFW_INTERSEC_SG_PUB} ] ; then
        `pyfunc virtual_ext_port_create`
        status=$?
        if [ $status != 0 ] ; then
           exit $status
        fi
    fi

    #Creation of the virtual LAN of tenant & port for vfw
    `pyfunc virtual_fw_tenant_vlan_port_create`
    status=$?

elif [ ${NAL_JOBNAME} = ${JOB_NAME_CREATE_PFW} ] ; then
    ###Physical FW creation###

    #Creation of the Pub port.
    `pyfunc physical_pub_port_create`
    status=$?
    if [ $status != 0 ] ; then
       exit $status
    fi

    #Creation of the Ext port.
    `pyfunc physical_ext_port_create`
    status=$?
    if [ $status != 0 ] ; then
       exit $status
    fi

    #Creation of the virtual LAN of tenant & port for pfw
    `pyfunc physical_fw_tenant_vlan_port_create`
    status=$?

elif [ ${NAL_JOBNAME} = ${JOB_NAME_CREATE_VLB} ] ; then
    ###Virtual LB creation###

    #Creation of the virtual LAN of tenant & port for vlb
    `pyfunc virtual_lb_tenant_vlan_port_create`
    status=$?

elif [ ${NAL_JOBNAME} = ${JOB_NAME_CREATE_PLB} ] ; then
    ###Physical LB creation###

    #Creation of the virtual LAN of tenant & port for plb
    `pyfunc physical_lb_tenant_vlan_port_create`
    status=$?
fi

exit $status