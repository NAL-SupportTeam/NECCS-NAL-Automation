#!/bin/sh

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#

#
#      Creation of MSA
#
. ${NALPATH}/common/NAL_C_Common.sh

#regist customer for MSA
`pyfunc msa_customer_create`
status=$?
if [ $status != 0 ] ; then
   exit $status
fi

#setup MSA
`pyfunc msa_setup_create`
status=$?
if [ $status != 0 ] ; then
   exit $status
fi

status=0
if [ ${NAL_JOBNAME} = ${JOB_NAME_CREATE_VFW} ] ; then
    ###Virtual FW creation###

    #In the case of InterSec(with Internet)
    if [ ${NAL_DEVICETYPE} = ${DEVTYPE_VFW_INTERSEC_SG_EXT} ] ; then
        `pyfunc device_setup_create_for_intersec_sg_internet`

    #In the case of InterSec(without Internet)
    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_VFW_INTERSEC_SG_PUB} ] ; then
        `pyfunc device_setup_create_for_intersec_sg_pub`

    #In the case of FortiGateVM
    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_VFW_FORTIGATE} ] ; then
        `pyfunc device_setup_create_for_fortigate_vm`

    #In the case of FortiGate5.4.1
    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_VFW_FORTIGATE541} ] ; then
        `pyfunc device_setup_create_for_fortigate_vm_541`

    #In the case of PaloaltoVM
    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_VFW_PALOALTO} ] ; then
        `pyfunc device_setup_create_for_paloalto_vm`
    fi
    status=$?

elif [ ${NAL_JOBNAME} = ${JOB_NAME_CREATE_PFW} ] ; then
    ###Physical FW creation###

    #In the case of Fortigate
    if [ ${NAL_DEVICETYPE} = ${DEVTYPE_PFW_FORTIGATE} ] ; then
        `pyfunc device_setup_create_for_fortigate`

    #In the case of Paloalto
    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_PFW_PALOALTO} ] ; then
        `pyfunc device_setup_create_for_paloalto`

    #In the case of Fortigate share
    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_PFW_FORTIGATE_SHARE} ] ; then
        `pyfunc device_setup_create_for_fortigate_share`
    fi
    status=$?

elif [ ${NAL_JOBNAME} = ${JOB_NAME_CREATE_VLB} ] ; then
    ###Virtual LB creation###

    #In the case of InterSecVM/LB
    if [ ${NAL_DEVICETYPE} = ${DEVTYPE_VLB_INTERSEC_LB} ] ; then
        `pyfunc device_setup_create_for_intersec_lb`

    #In the case of BIGIP
    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_VLB_BIGIP} ] ; then
        `pyfunc device_setup_create_for_bigip_ve`

    #In the case of vThunder
    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_VLB_VTHUNDER} ] ; then
        `pyfunc device_setup_create_for_vthunder`

    #In the case of vThunder4.1.1
    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_VLB_VTHUNDER411} ] ; then
        `pyfunc device_setup_create_for_vthunder411`
    fi
    status=$?

elif [ ${NAL_JOBNAME} = ${JOB_NAME_CREATE_PLB} ] ; then
    ###Physical LB creation###

    #In the case of BIGIP
    if [ ${NAL_DEVICETYPE} = ${DEVTYPE_PLB_BIGIP} ] ; then
        `pyfunc device_setup_create_for_bigip`

    #In the case of Thunder
    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_PLB_THUNDER} ] ; then
        `pyfunc device_setup_create_for_thunder`

    #In the case of BIGIP share
    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_PLB_BIGIP_SHARE} ] ; then
        `pyfunc device_setup_create_for_bigip_share`

    #In the case of Thunder share
    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_PLB_THUNDER_SHARE} ] ; then
        `pyfunc device_setup_create_for_thunder_share`
    fi
    status=$?
fi
exit $status
