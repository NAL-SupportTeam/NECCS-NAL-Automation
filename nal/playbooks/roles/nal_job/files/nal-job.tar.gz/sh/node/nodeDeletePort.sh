#!/bin/sh

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#

#
#      Along with the node removed, to remove the port
#
. ${NALPATH}/common/NAL_C_Common.sh

#Delete of the MSA port
status=0
if [ ${NAL_JOBNAME} = ${JOB_NAME_DELETE_VFW} -o ${NAL_JOBNAME} = ${JOB_NAME_DELETE_VLB}  ] ; then
    ###VNF deletetion###
    `pyfunc virtual_msa_port_delete`
    status=$?
    if [ $status != 0 ] ; then
        exit $status
    fi
fi

status=0
if [ ${NAL_JOBNAME} = ${JOB_NAME_DELETE_VFW} ] ; then
    ###Virtual FW deletion###

    #if that is not InterSec(with Internet), delete Pub port.
    if [ ${NAL_DEVICETYPE} != ${DEVTYPE_VFW_INTERSEC_SG_EXT} ] ; then
        `pyfunc virtual_pub_port_delete`
        status=$?
        if [ $status != 0 ] ; then
           exit $status
        fi
    fi

    #if that is not InterSec(without Internet), delete Ext port.
    if [ ${NAL_DEVICETYPE} != ${DEVTYPE_VFW_INTERSEC_SG_PUB} ] ; then
        `pyfunc virtual_ext_port_delete`
        status=$?
        if [ $status != 0 ] ; then
           exit $status
        fi
    fi

    #Deletion of the virtual LAN of tenant & port for vfw
    `pyfunc virtual_fw_tenant_vlan_port_delete`
    status=$?

elif [ ${NAL_JOBNAME} = ${JOB_NAME_DELETE_PFW} ] ; then
    ###Physical FW deletion###

    #Deletion of the Pub port.
    `pyfunc physical_pub_port_delete`
    status=$?
    if [ $status != 0 ] ; then
       exit $status
    fi

    #Deletion of the Ext port.
    `pyfunc physical_ext_port_delete`
    status=$?
    if [ $status != 0 ] ; then
       exit $status
    fi

    #Deletion of the virtual LAN of tenant & port for pfw
    `pyfunc physical_fw_tenant_vlan_port_delete`
    status=$?

elif [ ${NAL_JOBNAME} = ${JOB_NAME_DELETE_VLB} ] ; then
    ###Virtual LB deletion###

    #Deletion of the virtual LAN of tenant & port for vlb
    `pyfunc virtual_lb_tenant_vlan_port_delete`
    status=$?

elif [ ${NAL_JOBNAME} = ${JOB_NAME_DELETE_PLB} ] ; then
    ###Physical LB deletion###

    #Deletion of the virtual LAN of tenant & port for plb
    `pyfunc physical_lb_tenant_vlan_port_delete`
    status=$?
fi

exit $status




