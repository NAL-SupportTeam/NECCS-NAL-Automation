#!/bin/sh

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#

#
#      Delete of MSA
#
. ${NALPATH}/common/NAL_C_Common.sh

status=0
if [ ${NAL_JOBNAME} = ${JOB_NAME_DELETE_VPORT} ] ; then
    ###Virtual FW port delete###

    #In the case of InterSec(with Internet)
    if [ ${NAL_DEVICETYPE} = ${DEVTYPE_VFW_INTERSEC_SG_EXT} ] ; then
        `pyfunc msa_configuration_delete_for_intersec_sg_internet`

    #In the case of InterSec(without Internet)
    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_VFW_INTERSEC_SG_PUB} ] ; then
        `pyfunc msa_configuration_delete_for_intersec_sg_pub`
    fi
    status=$?

elif [ ${NAL_JOBNAME} = ${JOB_NAME_DELETE_PPORT} ] ; then
    ###Physical FW port delete###

    #In the case of Fortigate
    if [ ${NAL_DEVICETYPE} = ${DEVTYPE_PFW_FORTIGATE} ] ; then
        `pyfunc msa_configuration_delete_for_fortigate`

    #In the case of Paloalto
    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_PFW_PALOALTO} ] ; then
        `pyfunc msa_configuration_delete_for_paloalto`

    #In the case of Fortigate share
    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_PFW_FORTIGATE_SHARE} ] ; then
        `pyfunc msa_configuration_delete_for_fortigate_share`
    fi
    status=$?
fi
exit $status
