#!/bin/sh

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#

#
#      Port additional
#
. ${NALPATH}/common/NAL_C_Common.sh

status=0
if [ ${NAL_JOBNAME} = ${JOB_NAME_UPDATE_VFWIPV6ADD} ] ; then
    ###Virtual FW IPv6 add###

    # In case of INTERSEC_SG_EXT
    if [ ${NAL_DEVICETYPE} = ${DEVTYPE_VFW_INTERSEC_SG_EXT} ] ; then
        `pyfunc virtual_ext_port_add_ipv6`
        status=$?

    # In case of INTERSEC_SG_PUB
    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_VFW_INTERSEC_SG_PUB} ] ; then
        `pyfunc virtual_pub_port_add_ipv6`
        status=$?

    # In case of FORTIGATE or FORTIGATE541
    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_VFW_FORTIGATE} -o ${NAL_DEVICETYPE} = ${DEVTYPE_VFW_FORTIGATE541} ] ; then
        `pyfunc virtual_pub_port_add_ipv6`
        status=$?
        if [ $status != 0 ] ; then
            exit $status
        fi

        `pyfunc virtual_ext_port_add_ipv6`
        status=$?

    # In case of PALOALTO
    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_VFW_PALOALTO} ] ; then
        `pyfunc virtual_pub_port_add_ipv6`
        status=$?
        if [ $status != 0 ] ; then
            exit $status
        fi

        `pyfunc virtual_ext_port_add_ipv6`
        status=$?
    fi


    if [ $status != 0 ] ; then
        exit $status
    fi

    `pyfunc virtual_fw_tenant_vlan_port_add_ipv6`
    status=$?

elif [ ${NAL_JOBNAME} = ${JOB_NAME_UPDATE_VLBIPV6ADD} ] ; then
    ###Virtual LB IPv6 add###

    `pyfunc virtual_lb_tenant_vlan_port_add_ipv6`
    status=$?

fi
exit $status
