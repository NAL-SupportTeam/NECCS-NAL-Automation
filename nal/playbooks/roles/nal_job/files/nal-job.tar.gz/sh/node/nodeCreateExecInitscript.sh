#!/bin/sh

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#

#
#      Execute initialization script
#
. ${NALPATH}/common/NAL_C_Common.sh

# In the case of VNF creation, execute license auth script

status=0
if [ ${NAL_JOBNAME} = ${JOB_NAME_CREATE_VFW} ] ; then
    if [ ${NAL_DEVICETYPE} = ${DEVTYPE_VFW_INTERSEC_SG_EXT} -o ${NAL_DEVICETYPE} = ${DEVTYPE_VFW_INTERSEC_SG_PUB} ] ; then
        `pyfunc license_assign`
        status=$?
    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_VFW_FORTIGATE} ] ; then
        `pyfunc license_assign_fortigate_vm`
        status=$?
    fi
elif [ ${NAL_JOBNAME} = ${JOB_NAME_CREATE_VLB} ] ; then
    if [ ${NAL_DEVICETYPE} = ${DEVTYPE_VLB_INTERSEC_LB} ] ; then
        `pyfunc license_assign`
        status=$?
    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_VLB_BIGIP} ] ; then
        `pyfunc license_assign_bigip_ve`
        status=$?
    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_VLB_VTHUNDER} ] ; then
        `pyfunc zerotouch_vthunder`
        status=$?
    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_VLB_VTHUNDER411} ] ; then
        `pyfunc zerotouch_vthunder`
        status=$?
    fi
fi
exit $status
