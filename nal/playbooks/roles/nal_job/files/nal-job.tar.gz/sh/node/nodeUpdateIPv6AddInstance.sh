#!/bin/sh

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#

#
#      Instance addition
#
. ${NALPATH}/common/NAL_C_Common.sh

if [ ${NAL_JOBNAME} = ${JOB_NAME_UPDATE_VFWIPV6ADD} ] ; then
    ###Virtual FW IPv6 add###

    #Virtual FW instance port attach
    `pyfunc virtual_fw_interface_attach_ipv6`

elif [ ${NAL_JOBNAME} = ${JOB_NAME_UPDATE_VLBIPV6ADD} ] ; then
    ###Virtual LB IPv6 add###

    #Virtual LB instance port attach
    `pyfunc virtual_lb_interface_attach_ipv6`

fi
exit $?