#!/bin/sh

#
#  COPYRIGHT  (C)  NEC  CORPORATION  2016
#  NEC  CONFIDENTIAL  AND  PROPRIETARY
#
#   ALL RIGHTS RESERVED BY NEC CORPORATION. THIS PROGRAM MUST BE
#  USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY NEC
#  CORPORATION.  NO PART OF THIS PROGRAM MAY BE REPRODUCED OR
#  DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN
#  PERMISSION OF NEC CORPORATION.  USE OF COPYRIGHT NOTICE DOES
#  NOT EVIDENCE PUBLICATION OF THIS PROGRAM.
#

#
#      Along with the node removed, to remove the MSA
#
. ${NALPATH}/common/NAL_C_Common.sh

status=0
if [ ${NAL_JOBNAME} = ${JOB_NAME_DELETE_PFW} ] ; then
    ###PFW delettion###
    if [ ${NAL_DEVICETYPE} = ${DEVTYPE_PFW_FORTIGATE} ] ; then
        `pyfunc device_setup_delete_for_fortigate`
        status=$?

    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_PFW_PALOALTO} ] ; then
        `pyfunc device_setup_delete_for_paloalto`
        status=$?

    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_PFW_FORTIGATE_SHARE} ] ; then
        `pyfunc device_setup_delete_for_fortigate_share`
        status=$?
    fi
elif [ ${NAL_JOBNAME} = ${JOB_NAME_DELETE_PLB} ] ; then
    ###PLB delettion###
    if [ ${NAL_DEVICETYPE} = ${DEVTYPE_PLB_BIGIP} ] ; then
        `pyfunc device_setup_delete_for_bigip`
        status=$?

    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_PLB_THUNDER} ] ; then
        `pyfunc device_setup_delete_for_thunder`
        status=$?

    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_PLB_BIGIP_SHARE} ] ; then
        `pyfunc device_setup_delete_for_bigip_share`
        status=$?

    elif [ ${NAL_DEVICETYPE} = ${DEVTYPE_PLB_THUNDER_SHARE} ] ; then
        `pyfunc device_setup_delete_for_thunder_share`
        status=$?
    fi
fi

if [ $status != 0 ] ; then
    exit $status
fi

`pyfunc msa_setup_delete`
exit $?
